
package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.logica.Controladora;
import java.io.File;
import java.util.Date;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Ui_RegistrarAlumnoWindow extends javax.swing.JFrame {

    Controladora control= new Controladora();
    private File certMed;
    
    public Ui_RegistrarAlumnoWindow() {
        control = new Controladora();
        initComponents();
        JFileChooser fileChooser = new JFileChooser(); //archivo
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jLabel14 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        txtNombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtAPat = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtEstatura = new javax.swing.JTextField();
        chooserFeNac = new com.toedter.calendar.JDateChooser();
        txtCorreoE = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtContra = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtPade = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtAMat = new javax.swing.JTextField();
        txtPeso = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtAspi = new javax.swing.JTextArea();
        btnLimpiar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtDisPract2 = new javax.swing.JTextArea();
        jLabel18 = new javax.swing.JLabel();
        chkProfesionas = new javax.swing.JCheckBox();
        chkEstudios = new javax.swing.JCheckBox();
        txtDomicilio = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtEscuela = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtCarrera = new javax.swing.JTextField();
        txtProfesion = new javax.swing.JTextField();
        txtLugarT = new javax.swing.JTextField();
        txtPuesto = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        btnCertificado = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        txtCertMed = new javax.swing.JTextField();
        grado = new javax.swing.JComboBox<>();

        jScrollPane1.setViewportView(jTree1);

        jLabel14.setText("jLabel14");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setPreferredSize(new java.awt.Dimension(700, 600));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(33, 69, 113));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Registrar Alumno");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(199, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(196, 196, 196))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 90));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtNombre.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtNombre.setBorder(null);
        txtNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtNombreMousePressed(evt);
            }
        });
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        jPanel3.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 330, 20));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel3.setText("Nombre:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, -1, -1));

        jLabel4.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel4.setText("Apellido Paterno:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        txtAPat.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtAPat.setBorder(null);
        txtAPat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtAPatMousePressed(evt);
            }
        });
        txtAPat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAPatActionPerformed(evt);
            }
        });
        jPanel3.add(txtAPat, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 330, 20));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel5.setText("Apellido Materno:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel6.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel6.setText("<html>Fecha de nacimiento:</html> ");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, -1, -1));

        txtTelefono.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtTelefono.setBorder(null);
        txtTelefono.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtTelefonoMousePressed(evt);
            }
        });
        txtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefonoActionPerformed(evt);
            }
        });
        jPanel3.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 110, 140, 20));

        jLabel7.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel7.setText("Teléfono:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 110, -1, -1));

        txtEstatura.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtEstatura.setBorder(null);
        txtEstatura.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEstaturaMousePressed(evt);
            }
        });
        txtEstatura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstaturaActionPerformed(evt);
            }
        });
        jPanel3.add(txtEstatura, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 60, 120, 20));
        jPanel3.add(chooserFeNac, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 110, 20));

        txtCorreoE.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtCorreoE.setBorder(null);
        txtCorreoE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCorreoEMousePressed(evt);
            }
        });
        txtCorreoE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoEActionPerformed(evt);
            }
        });
        jPanel3.add(txtCorreoE, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 260, 330, 20));

        jLabel8.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel8.setText("Correo electrónico:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, -1, -1));

        jLabel10.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel10.setText("Contraseña:");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        txtContra.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        txtContra.setBorder(null);
        txtContra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtContraMousePressed(evt);
            }
        });
        txtContra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraActionPerformed(evt);
            }
        });
        jPanel3.add(txtContra, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 330, 20));

        jLabel11.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jLabel11.setText("Estatura:");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 60, 60, -1));

        jLabel12.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jLabel12.setText("Nivel de estudios:");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 110, 30));

        txtPade.setColumns(20);
        txtPade.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtPade.setRows(5);
        jScrollPane2.setViewportView(txtPade);

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 140, 100, 40));

        jLabel13.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jLabel13.setText("<html>Disciplinas prácticadas:</html> ");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 130, 40));

        jLabel16.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jLabel16.setText("Padecimientos:");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 150, 100, -1));

        txtAMat.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtAMat.setBorder(null);
        txtAMat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtAMatMousePressed(evt);
            }
        });
        txtAMat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAMatActionPerformed(evt);
            }
        });
        jPanel3.add(txtAMat, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 80, 330, 20));

        txtPeso.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtPeso.setBorder(null);
        txtPeso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtPesoMousePressed(evt);
            }
        });
        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });
        jPanel3.add(txtPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 90, 120, 20));

        jLabel17.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jLabel17.setText("Peso:");
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, 40, -1));

        txtAspi.setColumns(20);
        txtAspi.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtAspi.setRows(5);
        jScrollPane3.setViewportView(txtAspi);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 190, 100, 40));

        btnLimpiar.setBackground(new java.awt.Color(234, 69, 76));
        btnLimpiar.setFont(new java.awt.Font("Poppins", 1, 24)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiar.setText("Limpiar");
        btnLimpiar.setBorderPainted(false);
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLimpiarMouseClicked(evt);
            }
        });
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        jPanel3.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 370, 130, -1));

        btnGuardar.setBackground(new java.awt.Color(234, 69, 76));
        btnGuardar.setFont(new java.awt.Font("Poppins", 1, 24)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.setBorderPainted(false);
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel3.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, -1, -1));

        jLabel19.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jLabel19.setText("Edad:");
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 30, 60, -1));

        txtEdad.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtEdad.setBorder(null);
        txtEdad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEdadMousePressed(evt);
            }
        });
        txtEdad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEdadActionPerformed(evt);
            }
        });
        jPanel3.add(txtEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, 100, 30));

        txtDisPract2.setColumns(20);
        txtDisPract2.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtDisPract2.setRows(5);
        jScrollPane4.setViewportView(txtDisPract2);

        jPanel3.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, 330, 20));

        jLabel18.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jLabel18.setText("Aspiraciones:");
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 200, 90, -1));

        chkProfesionas.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        chkProfesionas.setText("¿Profesionista?");
        chkProfesionas.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                chkProfesionasItemStateChanged(evt);
            }
        });
        chkProfesionas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkProfesionasActionPerformed(evt);
            }
        });
        jPanel3.add(chkProfesionas, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, -1, -1));

        chkEstudios.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        chkEstudios.setText("¿Actualmente estudia?");
        chkEstudios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEstudiosActionPerformed(evt);
            }
        });
        jPanel3.add(chkEstudios, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, -1, -1));

        txtDomicilio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDomicilioActionPerformed(evt);
            }
        });
        jPanel3.add(txtDomicilio, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, 330, -1));

        jLabel2.setText("Domicilio:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, -1));

        txtEscuela.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEscuelaActionPerformed(evt);
            }
        });
        jPanel3.add(txtEscuela, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 330, -1));

        jLabel15.setText("Escuela:");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, -1, -1));

        jLabel20.setText("Carrera:");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 230, -1, -1));
        jPanel3.add(txtCarrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 330, -1));

        txtProfesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProfesionActionPerformed(evt);
            }
        });
        jPanel3.add(txtProfesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 380, 330, -1));
        jPanel3.add(txtLugarT, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 410, 330, -1));
        jPanel3.add(txtPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 440, 330, -1));

        jLabel21.setText("Puesto:");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 440, -1, -1));

        jLabel22.setText("Lugar de Trabajo:");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        jLabel23.setText("Profesion:");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 390, -1, -1));

        btnCertificado.setText("Subir");
        btnCertificado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCertificadoActionPerformed(evt);
            }
        });
        jPanel3.add(btnCertificado, new org.netbeans.lib.awtextra.AbsoluteConstraints(592, 240, 80, -1));

        jLabel24.setText("Certificado Medico:");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 240, -1, -1));

        txtCertMed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCertMedActionPerformed(evt);
            }
        });
        jPanel3.add(txtCertMed, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 270, 180, -1));

        grado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LICENCIATURA", "MAESTRIA", "DOCTORADO" }));
        jPanel3.add(grado, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 326, 330, 20));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 770, 500));

        pack();
    }// </editor-fold>                        

    private void camposVacios(String nombre, String apPat, String apMat, String telefono, String contrasena, String correoEP, String aspiraciones, String disciplinas, Date fechaSeleccionada){
        if (nombre.isEmpty() || apPat.isEmpty() || apMat.isEmpty() || telefono.isEmpty() ||
            contrasena.isEmpty() || correoEP.isEmpty() || aspiraciones.isEmpty() || disciplinas.isEmpty() ||
            fechaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Detiene la ejecución si hay campos vacíos
        }
    }
    
    private void txtCertMedActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void btnCertificadoActionPerformed(java.awt.event.ActionEvent evt) {                                               
        JFileChooser certificado = new JFileChooser();
        certificado.setFileSelectionMode(JFileChooser.FILES_ONLY);

        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos pdf o txt", "txt", "pdf");
        certificado.setFileFilter(filtro);

        int res = certificado.showOpenDialog(this);
        if (res != JFileChooser.CANCEL_OPTION) {
            certMed =certificado.getSelectedFile();

            if ((certMed == null)|| certMed.getName().equals("")) {
                JOptionPane.showMessageDialog(this, "Error al abrir el archivo.");
            }else{
                txtCertMed.setText(certMed.getAbsolutePath());
            }
        }
        //alumno.setCertificado(certMed);
    }  
    private void btnTutorActionPerformed(java.awt.event.ActionEvent evt) {                                               
        JFileChooser certificado = new JFileChooser();
        certificado.setFileSelectionMode(JFileChooser.FILES_ONLY);

        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos pdf o txt", "txt", "pdf");
        certificado.setFileFilter(filtro);

        int res = certificado.showOpenDialog(this);
        if (res != JFileChooser.CANCEL_OPTION) {
            certMed =certificado.getSelectedFile();

            if ((certMed == null)|| certMed.getName().equals("")) {
                JOptionPane.showMessageDialog(this, "Error al abrir el archivo.");
            }else{
                txtCertMed.setText(certMed.getAbsolutePath());
            }
        }
        //alumno.setCertificado(certMed);
    } 

    private void txtProfesionActionPerformed(java.awt.event.ActionEvent evt) {                                             
        // TODO add your handling code here:
    }                                            

    private void txtEscuelaActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void txtDomicilioActionPerformed(java.awt.event.ActionEvent evt) {                                             
        // TODO add your handling code here:
    }                                            

    private void chkEstudiosActionPerformed(java.awt.event.ActionEvent evt) {                                            
        //abre ui de estudios
    }                                           

    private void chkProfesionasActionPerformed(java.awt.event.ActionEvent evt) {                                               
        // TODO add your handling code here:
    }                                              

    private void chkProfesionasItemStateChanged(java.awt.event.ItemEvent evt) {                                                
        // TODO add your handling code here:
    }                                               

    private void txtEdadActionPerformed(java.awt.event.ActionEvent evt) {                                        
        // TODO add your handling code here:
    }                                       

    private void txtEdadMousePressed(java.awt.event.MouseEvent evt) {                                     
        // TODO add your handling code here:
    }                                    

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // Obtener datos del formulario
        String nombre = txtNombre.getText().trim();
        String apPat = txtAPat.getText().trim();
        String apMat = txtAMat.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String contrasena = txtContra.getText().trim();
        String correoEP = txtCorreoE.getText().trim();
        String aspiraciones = txtAspi.getText().trim();
        String disciplinas = txtDisPract2.getText().trim(); // Asegúrate de que el campo sea correcto
        Date fechaSeleccionada = chooserFeNac.getDate();
        String domicilio = txtDomicilio.getText().trim();
        int edad = Integer.parseInt(txtEdad.getText().trim());
        //LocalDate fechaActual = LocalDate.now(); // Obtener solo la fecha actual HAY QUE VER QUE SE IMPRIMA
        double peso = Double.parseDouble(txtPeso.getText().trim());
        double estatura = Double.parseDouble(txtEstatura.getText().trim());
        String padecimientos =txtPade.getText().trim();
        String est = grado.getSelectedItem().toString().trim();
        String esc = txtEscuela.getText().trim();
        String carrera = txtCarrera.getText().trim();
        String profesion = txtProfesion.getText().trim();
        String lugartrab = txtLugarT.getText().trim();
        String puesto = txtPuesto.getText().trim();
        Date fechaInscripcion = new Date();

        try {
            if (edad < 18) {
                //abrirNuevaPagina();
                Ui_MenorEdadAlumno screenAlumnoMenor = new Ui_MenorEdadAlumno();
                screenAlumnoMenor.setVisible(true);
                screenAlumnoMenor.setLocationRelativeTo(null);
            } else {
                JOptionPane.showMessageDialog(null, "Eres mayor de 18 años.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Por favor, ingresa un número válido.");
        }
        // Validaciones de campos vacíos
        if (nombre.isEmpty() || apPat.isEmpty() || apMat.isEmpty() || telefono.isEmpty() ||
            contrasena.isEmpty() || correoEP.isEmpty() || aspiraciones.isEmpty() || disciplinas.isEmpty() ||
            fechaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Detiene la ejecución si hay campos vacíos
        }

        control.guardarAlumno(nombre, apPat, apMat, domicilio, fechaSeleccionada, telefono, contrasena, correoEP, aspiraciones, peso, estatura, edad, padecimientos, est, esc, carrera, profesion, lugartrab, puesto, certMed, fechaInscripcion);
        JOptionPane optionPane = new JOptionPane("Se guardo correctamente");
        optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog("El alumno se ha registrado.");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);

    }                                          

    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {                                        
        // TODO add your handling code here:
        String nombre = txtNombre.getText();
        String apPat = txtAPat.getText();
        String apMat = txtAMat.getText();
        String telefono = txtTelefono.getText();
        String contrasena = txtContra.getText();
        String correoEP = txtCorreoE.getText();
        String aspiraciones = txtAspi.getText();
        String disciplinas = txtDisPract2.getText(); // Asegúrate de que el campo sea correcto
        String domicilio = txtDomicilio.getText();
        //LocalDate fechaActual= LocalDate.now();
        Double peso = Double.parseDouble(txtPeso.getText());
        Double estatura = Double.parseDouble(txtEstatura.getText());
        Date fechaSeleccionada = chooserFeNac.getDate();
        int edad = Integer.parseInt(txtEdad.getText());
        String padecimientos =txtPade.getText();
        String est = grado.getSelectedItem().toString().trim();
        String esc=txtEscuela.getText();
        String carrera = txtCarrera.getText();
        String profesion = txtProfesion.getText();
        String lugartrab = txtLugarT.getText();
        String puesto = txtPuesto.getText();
        Date fechaInscripcion = new Date();
    }                                       

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        txtNombre.setText("");
        txtEstatura.setText("");
        txtAPat.setText("");
        txtAMat.setText("");
        txtTelefono.setText("");
        txtContra.setText("");
        txtCorreoE.setText("");
        //txtGradoEs.setText("");
        txtDisPract2.setText("");
        chooserFeNac.setDate(null);
        txtPeso.setText("");
        txtEdad.setText("");
        txtPade.setText("");
        txtAspi.setText("");
    }                                          

    private void btnLimpiarMouseClicked(java.awt.event.MouseEvent evt) {                                        
        //javax.swing.JOptionPane.showMessageDialog(this,"Intento susario:\n "+jTextFieldCorreo2.getText(),String.valueOf(jPassword.getPassword())+"\n contrasenia: ");
        txtNombre.setText("");
        txtEstatura.setText("");
        txtAPat.setText("");
        txtAMat.setText("");
        txtTelefono.setText("");
        txtContra.setText("");
        txtCorreoE.setText("");
        //txtGradoEs.setText("");
        txtDisPract2.setText("");
        chooserFeNac.setDate(null);
        txtPeso.setText("");
        txtEstatura.setText("");
        txtPade.setText("");
        txtAspi.setText("");

    }                                       

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {                                        
        // TODO add your handling code here:
    }                                       

    private void txtPesoMousePressed(java.awt.event.MouseEvent evt) {                                     
        // TODO add your handling code here:
    }                                    

    private void txtAMatActionPerformed(java.awt.event.ActionEvent evt) {                                        
        // TODO add your handling code here:
    }                                       

    private void txtAMatMousePressed(java.awt.event.MouseEvent evt) {                                     
        // TODO add your handling code here:
    }                                    

    private void txtContraActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
    }                                         

    private void txtContraMousePressed(java.awt.event.MouseEvent evt) {                                       
        // TODO add your handling code here:
    }                                      

    private void txtCorreoEActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void txtCorreoEMousePressed(java.awt.event.MouseEvent evt) {                                        
        // TODO add your handling code here:
    }                                       

    private void txtEstaturaActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void txtEstaturaMousePressed(java.awt.event.MouseEvent evt) {                                         
        // TODO add your handling code here:
    }                                        

    private void txtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void txtTelefonoMousePressed(java.awt.event.MouseEvent evt) {                                         
        // TODO add your handling code here:
    }                                        

    private void txtAPatActionPerformed(java.awt.event.ActionEvent evt) {                                        
        // TODO add your handling code here:
    }                                       

    private void txtAPatMousePressed(java.awt.event.MouseEvent evt) {                                     
        // TODO add your handling code here:
    }                                    

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
    }                                         

    private void txtNombreMousePressed(java.awt.event.MouseEvent evt) {                                       
        // TODO add your handling code here:
    }                                      
  
    

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnCertificado;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JCheckBox chkEstudios;
    private javax.swing.JCheckBox chkProfesionas;
    private com.toedter.calendar.JDateChooser chooserFeNac;
    private javax.swing.JComboBox<String> grado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTree jTree1;
    private javax.swing.JTextField txtAMat;
    private javax.swing.JTextField txtAPat;
    private javax.swing.JTextArea txtAspi;
    private javax.swing.JTextField txtCarrera;
    private javax.swing.JTextField txtCertMed;
    private javax.swing.JTextField txtContra;
    private javax.swing.JTextField txtCorreoE;
    private javax.swing.JTextArea txtDisPract2;
    private javax.swing.JTextField txtDomicilio;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtEscuela;
    private javax.swing.JTextField txtEstatura;
    private javax.swing.JTextField txtLugarT;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextArea txtPade;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtProfesion;
    private javax.swing.JTextField txtPuesto;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration                   

}
