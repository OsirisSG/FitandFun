package com.mycompany.megafitandfun.logica;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Pago implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idPago;

    @Column(name = "CONCEPTO") // Asegúrate de que este nombre coincide con el de la base de datos
    private int concepto;

    @ManyToOne
    @JoinColumn(name = "idAlumno")
    private Alumno alumno;

    private Double monto;
    private String descripcion;

    @Temporal(TemporalType.DATE)
    private Date fechaPago;

    @Temporal(TemporalType.DATE)
    private Date fechaVencimiento; // Nueva variable para la fecha de vencimiento

    // Getters y Setters

    public Pago() {
    }

    public Pago(Alumno alumno, Double monto, int concepto, Date fechaPago, Date fechaVencimiento, String descripcion) {
        this.alumno = alumno;
        this.monto = monto;
        this.concepto = concepto;
        this.fechaPago = fechaPago;
        this.fechaVencimiento = fechaVencimiento;
        this.descripcion = descripcion;
    }

    public Integer getIdPago() {
        return idPago;
    }

    public void setIdPago(Integer idPago) {
        this.idPago = idPago;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public int getConcepto() {
        return concepto;
    }

    public void setConcepto(int concepto) {
        this.concepto = concepto;
    }

    public Date getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
