package com.mycompany.megafitandfun.logica;

import static com.mycompany.megafitandfun.logica.Profesor_.avances;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import java.util.List;

@Entity
public class Profesor implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idProfesor;

    private String nombre;
    private String apPat;
    private String apMat;
    private String telefono;
    private Date fechaNac;
    private Integer edad;
    private String email;
    private String password;
    private String especialidad;
    private String disciplinas;

    
    @OneToMany(mappedBy = "profesor", cascade = CascadeType.ALL)
    private List<Clase> clases;
    private List<Avance> avances;
    

    
    // Getters y Setters

    public Profesor() {
    }

    public Profesor(Integer idProfesor, String nombre, String apPat, String apMat, String telefono, Date fechaNac, Integer edad, String email, String password, String especialidad, String disciplinas, List<Clase> clases, List<Avance> avances) {
        this.idProfesor = idProfesor;
        this.nombre = nombre;
        this.apPat = apPat;
        this.apMat = apMat;
        this.telefono = telefono;
        this.fechaNac = fechaNac;
        this.edad = edad;
        this.email = email;
        this.password = password;
        this.especialidad = especialidad;
        this.disciplinas = disciplinas;
        this.clases = clases;
        this.avances = avances;
    }

    public Integer getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(Integer idProfesor) {
        this.idProfesor = idProfesor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPat() {
        return apPat;
    }

    public void setApPat(String apPat) {
        this.apPat = apPat;
    }

    public String getApMat() {
        return apMat;
    }

    public void setApMat(String apMat) {
        this.apMat = apMat;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(Date fechaNac) {
        this.fechaNac = fechaNac;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(String disciplinas) {
        this.disciplinas = disciplinas;
    }

    public List<Clase> getClases() {
        return clases;
    }

    public void setClases(List<Clase> clases) {
        this.clases = clases;
    }

    public List<Avance> getAvances() {
        return avances;
    }

    public void setAvances(List<Avance> avances) {
        this.avances = avances;
    }

    public void add(Profesor profesor) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
