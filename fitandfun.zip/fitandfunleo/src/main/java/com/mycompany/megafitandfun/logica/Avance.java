package com.mycompany.megafitandfun.logica;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Avance implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idAvance;

    @ManyToOne
    @JoinColumn(name = "idProfesor")  // Relaciona con la columna id_profesor en la tabla AVANCE
    private Profesor profesor;  // Se usa el objeto Profesor en lugar de idProfesor

    private int idAlumno;
    private Date fecha;
    private String comentario;
    private String linkVideo;
    
    // Almacenar el archivo PDF como un arreglo de bytes en la base de datos
    @Column(name = "ARCHIVOPDF")
    private byte[] archivoPDF;  // Cambiado a byte[] para almacenar el archivo PDF

    // Constructores
    public Avance() {
    }

    public Avance(Profesor profesor, int idAlumno, Date fecha, String comentario, String linkVideo, File archivoPDF) throws IOException {
        this.profesor = profesor;  // Asociar el objeto Profesor
        this.idAlumno = idAlumno;
        this.fecha = fecha;
        this.comentario = comentario;
        this.linkVideo = linkVideo;
        setArchivoPDFFile(archivoPDF);  // Convertir el archivo a un arreglo de bytes
    }

    // Getters y Setters
    public Integer getIdAvance() {
        return idAvance;
    }

    public void setIdAvance(Integer idAvance) {
        this.idAvance = idAvance;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public int getIdAlumno() {
        return idAlumno;
    }

    public void setIdAlumno(int idAlumno) {
        this.idAlumno = idAlumno;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getLinkVideo() {
        return linkVideo;
    }

    public void setLinkVideo(String linkVideo) {
        this.linkVideo = linkVideo;
    }

    public byte[] getArchivoPDF() {
        return archivoPDF;
    }

    // Establecer el archivo PDF como un arreglo de bytes
    public void setArchivoPDFFile(File archivoPDF) throws IOException {
        if (archivoPDF != null) {
            this.archivoPDF = new byte[(int) archivoPDF.length()];
            try (FileInputStream fis = new FileInputStream(archivoPDF)) {
                fis.read(this.archivoPDF);  // Leer el archivo PDF en un arreglo de bytes
            }
        }
    }
}
