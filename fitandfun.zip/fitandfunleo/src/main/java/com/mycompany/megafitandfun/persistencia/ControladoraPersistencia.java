
package com.mycompany.megafitandfun.persistencia;

import com.mycompany.megafitandfun.logica.Alumno;
import com.mycompany.megafitandfun.logica.Profesor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ControladoraPersistencia {
   
   // AdmiJpaController adminJpa = new AdmiJpaController(); ya se hizo
   AlumnoJpaController aluJPA = new AlumnoJpaController();
   AvanceJpaController avanceJPA = new AvanceJpaController();
   ClaseJpaController claseJPA = new ClaseJpaController();
   DiasJpaController diasJPA = new DiasJpaController();
   DisciplinaJpaController disciplinaJPA = new DisciplinaJpaController();
   NotificacionJpaController notisJPA = new NotificacionJpaController();
   PagoJpaController pagoJPA = new PagoJpaController();
   ReservaJpaController reservaJPA = new ReservaJpaController();
   ProfesorJpaController profeJPA = new ProfesorJpaController();
    
   public void saveProfe(Profesor profe){
       //crear profe en bd
       profeJPA.create(profe);
   }
   public void saveAlumno(Alumno alumno){
       //crear profe en bd
       aluJPA.create(alumno);
   }

   
   public List<Alumno> buscarAlumnosPorNombre(String nombre) {
    // Crear una lista para almacenar los alumnos encontrados
    List<Alumno> alumnos = new ArrayList<>();
    try {
        // Establecer conexión con la base de datos
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdfitandfun", "root", "");
        
        // Consulta para seleccionar alumnos con un nombre específico
        String sql = "SELECT * FROM alumno WHERE nombre = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, nombre);

        // Ejecutar la consulta y procesar los resultados
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            // Crear un objeto Alumno para cada registro encontrado
            Alumno alumno = new Alumno();
            alumno.setNombre(rs.getString("nombre")); 
            alumno.setApPat(rs.getString("APPAT")); 
            alumno.setApMat(rs.getString("APMAT")); 
            alumno.setIdAlumno(rs.getInt("IDALUMNO")); 
            alumno.setEmail(rs.getString("email"));  

            // Agregar el alumno a la lista
            alumnos.add(alumno);
        }

        // Cerrar recursos
        rs.close();
        stmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    // Retornar la lista de alumnos encontrados
    return alumnos;
}
        
  public boolean eliminarAlumno(int idAlumno) {
    boolean eliminado = false;
    try {
        // Establecer conexión con la base de datos
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdfitandfun", "root", "");
        
        // Consulta SQL para eliminar un alumno por su ID
        String sql = "DELETE FROM alumno WHERE IDALUMNO = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idAlumno);

        // Ejecutar la consulta de eliminación
        int filasAfectadas = stmt.executeUpdate();
        if (filasAfectadas > 0) {
            eliminado = true; // Indica que el alumno fue eliminado
        }

        // Cerrar recursos
        stmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return eliminado;
}

   public List<Profesor> buscarProfesoresPorNombre(String nombre) {
    // Crear una lista para almacenar los alumnos encontrados
    List<Profesor> profesores = new ArrayList<>();
    try {
        // Establecer conexión con la base de datos
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdfitandfun", "root", "");
        
        // Consulta para seleccionar alumnos con un nombre específico
        String sql = "SELECT * FROM profesor WHERE nombre = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, nombre);

        // Ejecutar la consulta y procesar los resultados
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            // Crear un objeto profeso para cada registro encontrado
            Profesor profesor = new Profesor();
            profesor.setNombre(rs.getString("nombre")); 
            profesor.setApPat(rs.getString("APPAT")); 
            profesor.setApMat(rs.getString("APMAT")); 
            profesor.setIdProfesor(rs.getInt("IDPROFESOR")); 
            profesor.setEmail(rs.getString("email"));  

            // Agregar el profesor a la lista
            profesor.add(profesor);
        }

        // Cerrar recursos
        rs.close();
        stmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    // Retornar la lista de alumnos encontrados
    return profesores;
}
   public boolean eliminarProfesor(int idProfesor) {
    boolean eliminado = false;
    try {
        // Establecer conexión con la base de datos
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdfitandfun", "root", "");
        
        // Consulta SQL para eliminar un alumno por su ID
        String sql = "DELETE FROM profesor WHERE IDPROFESOR = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idProfesor);

        // Ejecutar la consulta de eliminación
        int filasAfectadas = stmt.executeUpdate();
        if (filasAfectadas > 0) {
            eliminado = true; // Indica que el alumno fue eliminado
        }

        // Cerrar recursos
        stmt.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return eliminado;
}
}
