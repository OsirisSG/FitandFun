package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.logica.Clase;
import com.mycompany.megafitandfun.logica.Profesor;
import com.mycompany.megafitandfun.persistencia.ClaseJpaController;
import com.mycompany.megafitandfun.persistencia.ProfesorJpaController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JDialog;
import javax.swing.JOptionPane;


public class Ui_RegistrarClaseWindow extends javax.swing.JFrame {
    
    Clase clase =new Clase();
    ClaseJpaController controlClase =new ClaseJpaController();
    ProfesorJpaController controlProfe = new ProfesorJpaController();
    /**
     * Creates new form Ui_RegistrarClaseWindow
     */
    public Ui_RegistrarClaseWindow() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLocaleChooser1 = new com.toedter.components.JLocaleChooser();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtDisciplina = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        txtHorario = new javax.swing.JTextField();
        txtProfesor = new javax.swing.JTextField();
        txtDescripcion = new javax.swing.JTextField();
        txtCupo = new javax.swing.JTextField();
        btnRegistrarClase = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TXTListaProfes = new javax.swing.JTextArea();
        btnBuscarProfes = new javax.swing.JButton();
        fechaClase = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(33, 69, 113));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Registrar Clase");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(234, 234, 234)
                .addComponent(jLabel1)
                .addContainerGap(179, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(20, 20, 20))
        );

        jLabel2.setText("Disciplina:");

        jLabel3.setText("ID clase:");

        jLabel4.setText("Horario:");

        jLabel5.setText("ID Profesor:");

        jLabel6.setText("Descripcion:");

        jLabel7.setText("Cupo maximo:");

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        txtProfesor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProfesorActionPerformed(evt);
            }
        });

        btnRegistrarClase.setBackground(new java.awt.Color(234, 69, 76));
        btnRegistrarClase.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        btnRegistrarClase.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrarClase.setText("Guardar Clase");
        btnRegistrarClase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarClaseActionPerformed(evt);
            }
        });

        TXTListaProfes.setColumns(20);
        TXTListaProfes.setRows(5);
        jScrollPane1.setViewportView(TXTListaProfes);

        btnBuscarProfes.setBackground(new java.awt.Color(234, 69, 76));
        btnBuscarProfes.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        btnBuscarProfes.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarProfes.setText("Buscar Profesor");
        btnBuscarProfes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarProfesActionPerformed(evt);
            }
        });

        jLabel8.setText("Fecha:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 94, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(269, 269, 269)
                        .addComponent(btnRegistrarClase))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDescripcion)
                            .addComponent(txtDisciplina)
                            .addComponent(txtId)
                            .addComponent(txtHorario)
                            .addComponent(txtCupo)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(76, 76, 76)
                                .addComponent(btnBuscarProfes))
                            .addComponent(jScrollPane1))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(65, 65, 65)
                                .addComponent(fechaClase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtDisciplina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscarProfes)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fechaClase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(15, 15, 15)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(txtDescripcion, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRegistrarClase)
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void camposVacios(String disciplina, String horario, String idProf, String descripcion, String cupo){
        
    // Validar que no haya campos vacíos
        if (disciplina.isEmpty() || horario.isEmpty() || idProf.isEmpty() || descripcion.isEmpty() || cupo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Detiene la ejecución si hay campos vacíos
        }
    }
private void horariosNoValidos(String horario, String fecha) throws SQLException, ClassNotFoundException{
    Connection SQLConexion;
        
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/bdfitandfun"; // Cambia por tu base de datos
        String usuarioBD = "root"; // Usuario de la base de datos
        String passwordBD = ""; // Contraseña de la base de datos
        try{
            
            Class.forName(driver);
            SQLConexion = DriverManager.getConnection(url,usuarioBD, passwordBD);
            String queryAdmin = "SELECT HORARIO, FECHA FROM alumno";
            try (PreparedStatement stmt = SQLConexion.prepareStatement(queryAdmin)) {
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    String horarioP=rs.getString("HORARIO");
                    DateFormat formatter = new SimpleDateFormat("yyyy-M-d");
                    String fechaP = formatter.format(rs.getDate("FECHA"));

                    if(horarioP == horario && fechaP == fecha){
                        JOptionPane.showMessageDialog(this, "Horario invalido", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
                       
            }
        }catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        }
}
    private void btnRegistrarClaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarClaseActionPerformed
    // Obtener los valores de los campos
    String disciplina = txtDisciplina.getText().trim();
    String horario = txtHorario.getText().trim();
    String idProf = txtProfesor.getText().trim(); // Asumiendo que tienes un campo para el ID del profesor
    String descripcion = txtDescripcion.getText().trim();
    String cupo = txtCupo.getText().trim(); // El cupo se obtiene como texto y se valida antes de convertir
// Obtener la fecha actual
    Date fecha = fechaClase.getDate();
    // Validar que no haya campos vacíos
    if (disciplina.isEmpty() || horario.isEmpty() || idProf.isEmpty() || descripcion.isEmpty() || cupo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Detiene la ejecución si hay campos vacíos
    }
//controlClase.findProfesoresByNombre(profesor);
    // Validar y convertir el ID del profesor y el cupo
    int cupos;
    int idProfe;
    try {
        idProfe = Integer.parseInt(idProf);
        cupos = Integer.parseInt(cupo); // Convertir el cupo a entero
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El ID del profesor y el cupo deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Detiene la ejecución si los valores no son válidos
    }
    
    Profesor prof=controlProfe.findProfesor(idProfe);
    
    
    clase = new Clase(fecha, horario, disciplina, descripcion, cupos, prof);
    controlClase.guardar(clase);
    
        JOptionPane optionPane = new JOptionPane("Se guardo correctamente");
        optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog("La clase se ha registrado.");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);   
    }//GEN-LAST:event_btnRegistrarClaseActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void txtProfesorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProfesorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProfesorActionPerformed

    private void btnBuscarProfesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarProfesActionPerformed
         // Solicitar el nombre del alumno a buscar
    String nombreBuscar = JOptionPane.showInputDialog("Dame solo el nombre del profesor a buscar");

    // Validar que se haya ingresado un nombre
    if (nombreBuscar == null || nombreBuscar.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingresa un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    List<Profesor> profesoresEncontrados = controlProfe.findProfesoresByNombre(nombreBuscar);
     if (!profesoresEncontrados.isEmpty()) {
        TXTListaProfes.append("Profes encontrados con el nombre: " + nombreBuscar + "\n\n");
        for (Profesor profe : profesoresEncontrados) {
            TXTListaProfes.append("Nombre: " + profe.getNombre() + " "+ profe.getApPat()+" "+profe.getApMat() + "\n");
            TXTListaProfes.append("ID: " + profe.getIdProfesor()+ "\n");
            TXTListaProfes.append("-------------------------------------------\n");
        }
    } else {
        TXTListaProfes.append("No se encontraron profesores con el nombre: " + nombreBuscar + "\n");
    }
    }//GEN-LAST:event_btnBuscarProfesActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea TXTListaProfes;
    private javax.swing.JButton btnBuscarProfes;
    private javax.swing.JButton btnRegistrarClase;
    private com.toedter.calendar.JDateChooser fechaClase;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private com.toedter.components.JLocaleChooser jLocaleChooser1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCupo;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtDisciplina;
    private javax.swing.JTextField txtHorario;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtProfesor;
    // End of variables declaration//GEN-END:variables
}
