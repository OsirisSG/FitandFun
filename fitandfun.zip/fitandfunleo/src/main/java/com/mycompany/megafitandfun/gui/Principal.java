
package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.Sesion;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;


public class Principal extends javax.swing.JFrame {

    
    public Principal() {
        initComponents();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        txtCorreo = new javax.swing.JTextField();
        txtContrasenia = new javax.swing.JPasswordField();
        btnIniciarSesion = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jPanel4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImages(null);
        setLocationByPlatform(true);
        setPreferredSize(new java.awt.Dimension(700, 600));
        setResizable(false);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Poppins", 0, 36)); // NOI18N
        jLabel1.setText("BIENVENIDO");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, -1, -1));

        jLabel2.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel2.setText("Contraseña: ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        jLabel4.setFont(new java.awt.Font("Poppins", 0, 18)); // NOI18N
        jLabel4.setText("Ingresa tus datos:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, -1, -1));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel5.setText("Correo electrónico:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, -1));

        jSeparator2.setBackground(new java.awt.Color(0, 0, 255));
        jSeparator2.setForeground(new java.awt.Color(33, 69, 113));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 290, 20));

        txtCorreo.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtCorreo.setForeground(new java.awt.Color(204, 204, 204));
        txtCorreo.setText("Ingresa tu correo electrónico");
        txtCorreo.setBorder(null);
        txtCorreo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txtCorreo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCorreoFocusGained(evt);
            }
        });
        txtCorreo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCorreoMousePressed(evt);
            }
        });
        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });
        jPanel1.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, 290, 30));

        txtContrasenia.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtContrasenia.setForeground(new java.awt.Color(204, 204, 204));
        txtContrasenia.setText("********");
        txtContrasenia.setBorder(null);
        txtContrasenia.setCaretColor(new java.awt.Color(204, 204, 204));
        txtContrasenia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txtContrasenia.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtContraseniaFocusGained(evt);
            }
        });
        txtContrasenia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtContraseniaMousePressed(evt);
            }
        });
        jPanel1.add(txtContrasenia, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, 290, 30));

        btnIniciarSesion.setBackground(new java.awt.Color(234, 69, 76));
        btnIniciarSesion.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        btnIniciarSesion.setForeground(new java.awt.Color(255, 255, 255));
        btnIniciarSesion.setText("Iniciar Sesión");
        btnIniciarSesion.setBorderPainted(false);
        btnIniciarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnIniciarSesionMouseClicked(evt);
            }
        });
        btnIniciarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarSesionActionPerformed(evt);
            }
        });
        jPanel1.add(btnIniciarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, -1, -1));

        jSeparator3.setBackground(new java.awt.Color(0, 0, 255));
        jSeparator3.setForeground(new java.awt.Color(33, 69, 113));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 290, 20));

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 360, 580));

        jPanel4.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 580, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 390, 580));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void verificarInicioSesion(String email,String password){
        String url = "jdbc:mysql://localhost:3306/bdfitandfun"; // Cambia por tu base de datos
    String usuarioBD = "root"; // Usuario de la base de datos
    String passwordBD = ""; // Contraseña de la base de datos

    try (Connection conexion = DriverManager.getConnection(url, usuarioBD, passwordBD)) {
        // Verificar en la tabla de administradores
        String queryAdmin = "SELECT IDADMIN FROM admi WHERE EMAIL_AD = ? AND CONTRA_AD = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(queryAdmin)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int idAdmin = rs.getInt("IDADMIN");
                JOptionPane.showMessageDialog(null, "Bienvenido, administrador.");
                Sesion.setIdUsuario(idAdmin, "Admin"); 
                Ui_PrincipalAdminWindow1 screenAdmin = new Ui_PrincipalAdminWindow1(idAdmin);
                screenAdmin.setVisible(true);
                screenAdmin.setLocationRelativeTo(null);
                this.dispose();    
                return;
            }
        }

        // Verificar en la tabla de profesores
        String queryProfesor = "SELECT IDPROFESOR FROM profesor WHERE EMAIL = ? AND PASSWORD = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(queryProfesor)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int idProfesor = rs.getInt("IDPROFESOR");
                JOptionPane.showMessageDialog(null, "Bienvenido, profesor.");
                Sesion.setIdUsuario(idProfesor, "Profesor");
                Ui_PrincipalProfesorWindow screenProfe = new Ui_PrincipalProfesorWindow(idProfesor);
                screenProfe.setVisible(true);
                screenProfe.setLocationRelativeTo(null);
                this.dispose(); 
                return;
            }
        }

        // Verificar en la tabla de alumnos
        String queryAlumno = "SELECT IDALUMNO FROM alumno WHERE EMAIL = ? AND PASSWORD = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(queryAlumno)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int idAlumno = rs.getInt("IDALUMNO");
                JOptionPane.showMessageDialog(null, "Bienvenido, alumno.");
                Sesion.setIdUsuario(idAlumno, "Alumno");  // Almacenar el id del usuario y tip
                Ui_PrincipalAlumnoWindow screenAlu = new Ui_PrincipalAlumnoWindow(idAlumno);
                screenAlu.setVisible(true);
                screenAlu.setLocationRelativeTo(null);
                this.dispose(); 
                return;
            }
        }   catch (SQLException ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }   catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void btnIniciarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarSesionActionPerformed
        String email = txtCorreo.getText();
    String password = new String(txtContrasenia.getPassword());
    int idgeneral;

    if (email.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor llena todos los campos");
        return;
    }
    String url = "jdbc:mysql://localhost:3306/bdfitandfun"; // Cambia por tu base de datos
    String usuarioBD = "root"; // Usuario de la base de datos
    String passwordBD = ""; // Contraseña de la base de datos

    try (Connection conexion = DriverManager.getConnection(url, usuarioBD, passwordBD)) {
        // Verificar en la tabla de administradores
        String queryAdmin = "SELECT IDADMIN FROM admi WHERE EMAIL_AD = ? AND CONTRA_AD = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(queryAdmin)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int idAdmin = rs.getInt("IDADMIN");
                JOptionPane.showMessageDialog(null, "Bienvenido, administrador.");
                Sesion.setIdUsuario(idAdmin, "Admin"); 
                Ui_PrincipalAdminWindow1 screenAdmin = new Ui_PrincipalAdminWindow1(idAdmin);
                screenAdmin.setVisible(true);
                screenAdmin.setLocationRelativeTo(null);
                this.dispose();    
                return;
            }
        }

        // Verificar en la tabla de profesores
        String queryProfesor = "SELECT IDPROFESOR FROM profesor WHERE EMAIL = ? AND PASSWORD = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(queryProfesor)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int idProfesor = rs.getInt("IDPROFESOR");
                JOptionPane.showMessageDialog(null, "Bienvenido, profesor.");
                Sesion.setIdUsuario(idProfesor, "Profesor");
                Ui_PrincipalProfesorWindow screenProfe = new Ui_PrincipalProfesorWindow(idProfesor);
                screenProfe.setVisible(true);
                screenProfe.setLocationRelativeTo(null);
                this.dispose(); 
                return;
            }
        }

        // Verificar en la tabla de alumnos
        String queryAlumno = "SELECT IDALUMNO FROM alumno WHERE EMAIL = ? AND PASSWORD = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(queryAlumno)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int idAlumno = rs.getInt("IDALUMNO");
                JOptionPane.showMessageDialog(null, "Bienvenido, alumno.");
                Sesion.setIdUsuario(idAlumno, "Alumno");  // Almacenar el id del usuario y tip
                Ui_PrincipalAlumnoWindow screenAlu = new Ui_PrincipalAlumnoWindow(idAlumno);
                screenAlu.setVisible(true);
                screenAlu.setLocationRelativeTo(null);
                this.dispose(); 
                return;
            }
        }
           
        // Si no se encontró en ninguna tabla
        JOptionPane.showMessageDialog(null, "Credenciales incorrectas.");
        txtCorreo.setText("");
        txtContrasenia.setText("");
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
    }
    
    }//GEN-LAST:event_btnIniciarSesionActionPerformed

    private void btnIniciarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnIniciarSesionMouseClicked
        //javax.swing.JOptionPane.showMessageDialog(this,"Intento susario:\n "+jTextFieldCorreo2.getText(),String.valueOf(jPassword.getPassword())+"\n contrasenia: ");

    }//GEN-LAST:event_btnIniciarSesionMouseClicked

    private void txtContraseniaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtContraseniaMousePressed
        if(String.valueOf(txtContrasenia.getPassword()).equals("********")){
            txtContrasenia.setText("");
            txtContrasenia.setForeground(Color.gray);
        }
        if(txtCorreo.getText().isEmpty()){
            txtCorreo.setText("Ingresa tu correo electrónico");
            txtCorreo.setForeground(Color.gray);
        }

    }//GEN-LAST:event_txtContraseniaMousePressed

    private void txtContraseniaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtContraseniaFocusGained
        txtContrasenia.setFocusable(true);
    }//GEN-LAST:event_txtContraseniaFocusGained

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void txtCorreoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCorreoMousePressed

        if(txtCorreo.getText().equals("Ingresa tu correo electrónico")){
            txtCorreo.setText("");
            txtCorreo.setForeground(Color.black);
        }
        if(String.valueOf(txtContrasenia.getPassword()).isEmpty()){
            txtContrasenia.setText("********");
            txtContrasenia.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtCorreoMousePressed

    private void txtCorreoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCorreoFocusGained
        txtCorreo.setFocusable(true); // Permitir foco cuando se haga clic
    }//GEN-LAST:event_txtCorreoFocusGained
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIniciarSesion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JPasswordField txtContrasenia;
    private javax.swing.JTextField txtCorreo;
    // End of variables declaration//GEN-END:variables
}
