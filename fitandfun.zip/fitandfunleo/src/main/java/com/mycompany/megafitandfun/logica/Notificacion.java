
package com.mycompany.megafitandfun.logica;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class Notificacion implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idNotificacion;

    @ManyToOne
    @JoinColumn(name = "idProfesor")
    private Profesor profesor;

    @ManyToOne
    @JoinColumn(name = "idAlumno")
    private Alumno alumno;
    @Temporal(TemporalType.DATE)
    private Date fechaEnvio;

    @Enumerated(EnumType.STRING)
    private Tipo tipo;

    private String mensaje;

    public enum Tipo {
        GENERAL, URGENTE
    }

    // Getters y Setters

    public Notificacion() {
    }

    public Notificacion(Integer idNotificacion, Profesor profesor, Alumno alumno, Date fechaEnvio, Tipo tipo, String mensaje) {
        this.idNotificacion = idNotificacion;
        this.profesor = profesor;
        this.alumno = alumno;
        this.fechaEnvio = fechaEnvio;
        this.tipo = tipo;
        this.mensaje = mensaje;
    }

    public Integer getIdNotificacion() {
        return idNotificacion;
    }

    public void setIdNotificacion(Integer idNotificacion) {
        this.idNotificacion = idNotificacion;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Date getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(Date fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
}