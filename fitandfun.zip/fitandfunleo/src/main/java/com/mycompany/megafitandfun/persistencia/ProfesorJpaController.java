package com.mycompany.megafitandfun.persistencia;

import com.mycompany.megafitandfun.logica.Profesor;
import com.mycompany.megafitandfun.persistencia.exceptions.NonexistentEntityException;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.io.Serializable;
import java.util.List;

public class ProfesorJpaController implements Serializable {

    private EntityManagerFactory emf = null;

    public ProfesorJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public ProfesorJpaController() {
        emf = Persistence.createEntityManagerFactory("fitandJPAPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Profesor profesor) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(profesor); // No relaciones complejas, guardar el profesor directamente
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Profesor profesor) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            if (findProfesor(profesor.getIdProfesor()) == null) {
                throw new NonexistentEntityException("El profesor con ID " + profesor.getIdProfesor() + " no existe.");
            }
            em.merge(profesor); // Actualiza el profesor directamente
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Profesor profesor = em.find(Profesor.class, id);
            if (profesor == null) {
                throw new NonexistentEntityException("El profesor con ID " + id + " no existe.");
            }
            em.remove(profesor); // No manejo adicional de relaciones
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public Profesor findProfesor(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Profesor.class, id);
        } finally {
            em.close();
        }
    }

    public List<Profesor> findProfesorEntities() {
        return findProfesorEntities(true, -1, -1);
    }

    public List<Profesor> findProfesorEntities(int maxResults, int firstResult) {
        return findProfesorEntities(false, maxResults, firstResult);
    }

    private List<Profesor> findProfesorEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Profesor.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Profesor> findProfesoresByNombre(String nombre) {
        EntityManager em = getEntityManager();
        try {
            Query query = em.createQuery("SELECT p FROM Profesor p WHERE p.nombre LIKE :nombre", Profesor.class);
            query.setParameter("nombre", "%" + nombre + "%"); // Búsqueda parcial
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public Profesor encontrarProfesorPorId(int idProfesor) {
    EntityManager em = getEntityManager();
    try {
        Profesor profesor = em.find(Profesor.class, idProfesor);
        if (profesor == null) {
            // Puedes lanzar una excepción o retornar un valor especial si no se encuentra el profesor
            System.out.println("Profesor con ID " + idProfesor + " no encontrado.");
            return null;  // O lanzar una excepción personalizada si lo prefieres
        }
        return profesor;  // Retorna el objeto Profesor
    } finally {
        em.close();
    }
}
    
    public int getProfesorCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Profesor> rt = cq.from(Profesor.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
}
