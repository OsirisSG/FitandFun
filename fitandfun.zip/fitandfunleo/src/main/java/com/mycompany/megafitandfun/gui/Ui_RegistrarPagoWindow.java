
package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.logica.Alumno;
import com.mycompany.megafitandfun.logica.Pago;
import com.mycompany.megafitandfun.persistencia.AlumnoJpaController;
import com.mycompany.megafitandfun.persistencia.PagoJpaController;
import java.awt.HeadlessException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
//import jakarta.mail.*;
//import jakarta.mail.internet.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;




public class Ui_RegistrarPagoWindow extends javax.swing.JFrame {

    AlumnoJpaController controlAlumno= new AlumnoJpaController();
    PagoJpaController controlPago = new PagoJpaController();
    Pago pago= new Pago();
    public Ui_RegistrarPagoWindow() {
        //control = new Controladora();
        initComponents();
    }

private void enviarCorreo(String destinatario, double monto, String descripcion, Date fechaPago, Date vencimiento) throws AddressException, MessagingException {
    try {
        // Configuración del servidor SMTP
        String host = "smtp.gmail.com";
        String puerto = "587";
        String remitente = "leonforce033@gmail.com"; // Tu correo
        String clave = "qhsfmiujcxlcowao"; // Tu contraseña de correo

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", puerto);

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, clave);
            }
        });

        // Formatear las fechas
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaPagoStr = sdf.format(fechaPago);
        String vencimientoStr = sdf.format(vencimiento);

        // Crear el mensaje
        Message mensaje = new MimeMessage(session);
        mensaje.setFrom(new InternetAddress(remitente));
        mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
        mensaje.setSubject("Confirmación de Pago");
        mensaje.setText("Hola,\n\nSe ha registrado un pago con los siguientes detalles:\n\n"
                + "Alumno: " + destinatario + "\n"
                        + "Monto: $" + monto + "\n"
                                + "Descripción: " + descripcion + "\n"
                                        + "Fecha de pago: " + fechaPagoStr + "\n"
                                                + "Fecha de vencimiento: " + vencimientoStr + "\n\n"
                                                        + "Gracias por tu pago.\n\n"
                                                        + "Saludos,\nEquipo de Finanzas");
        // Enviar el mensaje
        Transport.send(mensaje);
        System.out.println("Correo enviado exitosamente.");


        //System.out.println("Correo enviado exitosamente.");

    } catch (Exception e) {
        // Manejo de errores
        System.err.println("Error al enviar el correo: " + e.getMessage());
        e.printStackTrace();
    }
}
    private void camposVacios(String alumno, String montoPago, String descripcion, Date fechaPago, Date vencimiento){
        if (alumno.isEmpty() || montoPago.isEmpty() || descripcion.isEmpty() || fechaPago == null || vencimiento == null) {
        JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }   
    }
    private void alumnoNotFound(Alumno alum, int idalumno){
        if (alum == null) {
        JOptionPane.showMessageDialog(this, "No se encontró un alumno con el ID: " + idalumno, "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        txtNombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        chooserFeNac = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDisPract = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        btnLimpiar = new javax.swing.JButton();
        btnRegistrar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtMonto = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtListaAlumnos = new javax.swing.JTextArea();
        btnBuscarAlumno = new javax.swing.JButton();
        cbxPaquetes = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        chooserVenc = new com.toedter.calendar.JDateChooser();

        jScrollPane1.setViewportView(jTree1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(33, 69, 113));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Registrar Pago");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(199, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(196, 196, 196))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 90));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtNombre.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtNombre.setBorder(null);
        txtNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtNombreMousePressed(evt);
            }
        });
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        jPanel3.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 110, 20));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel3.setText("ID Alumno:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        jLabel4.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel4.setText("Monto:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, -1, -1));
        jPanel3.add(chooserFeNac, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, 110, 20));

        jLabel8.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel8.setText("Concepto:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, -1, -1));

        txtDisPract.setColumns(20);
        txtDisPract.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtDisPract.setRows(5);
        jScrollPane2.setViewportView(txtDisPract);

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 320, 70));
        jPanel3.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        btnLimpiar.setBackground(new java.awt.Color(234, 69, 76));
        btnLimpiar.setFont(new java.awt.Font("Poppins", 1, 24)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiar.setText("Limpiar");
        btnLimpiar.setBorderPainted(false);
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLimpiarMouseClicked(evt);
            }
        });
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        jPanel3.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 400, 160, -1));

        btnRegistrar.setBackground(new java.awt.Color(234, 69, 76));
        btnRegistrar.setFont(new java.awt.Font("Poppins", 1, 24)); // NOI18N
        btnRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrar.setText("Registrar");
        btnRegistrar.setBorderPainted(false);
        btnRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistrarMouseClicked(evt);
            }
        });
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });
        jPanel3.add(btnRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 400, -1, -1));

        jLabel9.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel9.setText("Descripción:");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));

        jLabel10.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel10.setText("Fecha de Pago:");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, 20));

        txtMonto.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtMonto.setBorder(null);
        txtMonto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtMontoMousePressed(evt);
            }
        });
        txtMonto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMontoActionPerformed(evt);
            }
        });
        jPanel3.add(txtMonto, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, 320, 20));

        txtListaAlumnos.setColumns(20);
        txtListaAlumnos.setRows(5);
        jScrollPane3.setViewportView(txtListaAlumnos);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 56, 320, 100));

        btnBuscarAlumno.setText("Buscar Alumno");
        btnBuscarAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarAlumnoActionPerformed(evt);
            }
        });
        jPanel3.add(btnBuscarAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, -1, -1));

        cbxPaquetes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        cbxPaquetes.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                cbxPaquetesComponentShown(evt);
            }
        });
        cbxPaquetes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxPaquetesActionPerformed(evt);
            }
        });
        jPanel3.add(cbxPaquetes, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 40, 20));

        jLabel2.setText("<html>Cada paquete incluye el numero <br\\>de clases del paquete<html\\>");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, -1, -1));

        jLabel5.setText("Fecha de Vencimiento:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, -1, -1));
        jPanel3.add(chooserVenc, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 700, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLimpiarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarMouseClicked
        //javax.swing.JOptionPane.showMessageDialog(this,"Intento susario:\n "+jTextFieldCorreo2.getText(),String.valueOf(jPassword.getPassword())+"\n contrasenia: ");
        txtNombre.setText("");
        txtMonto.setText("");
        chooserFeNac.setDate(null);
        txtDisPract.setText("");
        txtDisPract.setText("");
        

    }//GEN-LAST:event_btnLimpiarMouseClicked

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtNombre.setText("");
        txtMonto.setText("");
        chooserFeNac.setDate(null);
        txtDisPract.setText("");
        txtDisPract.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistrarMouseClicked
        String nombre = txtNombre.getText();
        String montoPago = txtMonto.getText();
        String descripcion = txtDisPract.getText();
        String concepto = cbxPaquetes.getSelectedItem().toString();
        Date fechaPago = chooserFeNac.getDate();// TODO add your handling code here:
    }//GEN-LAST:event_btnRegistrarMouseClicked

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
 // Obtener datos del formulario
    // Obtener datos del formulario
    String alumno = txtNombre.getText().trim();
    String montoPago = txtMonto.getText().trim();
    String descripcion = txtDisPract.getText().trim();
    int concepto = Integer.parseInt(cbxPaquetes.getSelectedItem().toString().trim());
    Date fechaPago = chooserFeNac.getDate();
    Date vencimiento = chooserVenc.getDate();

    // Validaciones de campos vacíos
    //camposVacios();
    if (alumno.isEmpty() || montoPago.isEmpty() || descripcion.isEmpty() || fechaPago == null || vencimiento == null) {
        JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    double monto;
    int idalumno;

    try {
        idalumno = Integer.parseInt(alumno); // Asume que `txtNombre` contiene el ID del alumno
        monto = Double.parseDouble(montoPago);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El ID del alumno y el monto deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Buscar el alumno por ID
    Alumno alum = controlAlumno.findAlumno(idalumno);
    //alumnoNotFound();
    if (alum == null) {
        JOptionPane.showMessageDialog(this, "No se encontró un alumno con el ID: " + idalumno, "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Crear el pago y registrar
    Pago pago = new Pago(alum, monto, concepto, fechaPago, vencimiento, descripcion);
    controlPago.create(pago);

    // Enviar correo
    try {
        enviarCorreo(alum.getEmail(), monto, descripcion, fechaPago, vencimiento);
        JOptionPane.showMessageDialog(this, "El pago se registró exitosamente y se envió el correo.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (com.mycompany.megafitandfun.gui.MessagingException | HeadlessException | AddressException e) {
        JOptionPane.showMessageDialog(this, "El pago se registró pero no se pudo enviar el correo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    
    
    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNombreMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreMousePressed

    private void txtMontoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtMontoMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMontoMousePressed

    private void txtMontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMontoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMontoActionPerformed

    private void btnBuscarAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarAlumnoActionPerformed
    // Solicitar el nombre del alumno a buscar
    String nombreBuscar = JOptionPane.showInputDialog("Dame el nombre del alumno a buscar");

    // Validar que se haya ingresado un nombre
    if (nombreBuscar == null || nombreBuscar.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingresa un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Llamar al controlador para obtener la lista de alumnos
    List<Alumno> alumnosEncontrados = controlAlumno.findAlumnosByNombre(nombreBuscar);

    // Verificar si se encontraron alumnos
    if (!alumnosEncontrados.isEmpty()) {
        txtListaAlumnos.append("Alumnos encontrados con el nombre: " + nombreBuscar + "\n\n");
        for (Alumno alumno : alumnosEncontrados) {
            txtListaAlumnos.append("Nombre: " + nombreBuscar + " "+ alumno.getApPat() + " "+ alumno.getApMat() + " "+"\n");
            txtListaAlumnos.append("ID: " + alumno.getIdAlumno() + "\n");
            txtListaAlumnos.append("-------------------------------------------\n");
        }
    } else {
        txtListaAlumnos.append("No se encontraron alumnos con el nombre: " + nombreBuscar + "\n");
    }
    }//GEN-LAST:event_btnBuscarAlumnoActionPerformed

    private void cbxPaquetesComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_cbxPaquetesComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxPaquetesComponentShown

    private void cbxPaquetesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxPaquetesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxPaquetesActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarAlumno;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JComboBox<String> cbxPaquetes;
    private com.toedter.calendar.JDateChooser chooserFeNac;
    private com.toedter.calendar.JDateChooser chooserVenc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTree jTree1;
    private javax.swing.JTextArea txtDisPract;
    private javax.swing.JTextArea txtListaAlumnos;
    private javax.swing.JTextField txtMonto;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
