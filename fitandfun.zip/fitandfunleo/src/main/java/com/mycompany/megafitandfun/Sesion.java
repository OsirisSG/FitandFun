/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.megafitandfun;

public class Sesion {
    private static int idUsuario;  // Variable estática para almacenar el ID del usuario
    private static String tipoUsuario;  // Para identificar si es Admin, Profesor, o Alumno

    // Métodos para obtener y modificar el idUsuario
    public static int getIdUsuario() {
        return idUsuario;
    }

    public static void setIdUsuario(int id, String tipo) {
        idUsuario = id;
        tipoUsuario = tipo;
    }

    public static String getTipoUsuario() {
        return tipoUsuario;
    }
}
