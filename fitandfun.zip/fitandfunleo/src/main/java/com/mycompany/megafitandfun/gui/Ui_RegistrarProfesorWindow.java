
package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.logica.Controladora;
import com.mycompany.megafitandfun.logica.Profesor;
import com.mycompany.megafitandfun.persistencia.AlumnoJpaController;
import com.mycompany.megafitandfun.persistencia.ProfesorJpaController;
import java.util.Date;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Ui_RegistrarProfesorWindow extends javax.swing.JFrame {
    ProfesorJpaController controlProfesor= new ProfesorJpaController();
    Controladora control= new Controladora();
    public Ui_RegistrarProfesorWindow() {
        //control = new Controladora();
        initComponents();
    }
    private void camposVacios(String nombre, String apPat, String apMat, String telefono, String contrasena, String correoEP, String espe, String disciplinas, Date fechaSeleccionada){
        if (nombre.isEmpty() || apPat.isEmpty() || apMat.isEmpty() || telefono.isEmpty() || 
            contrasena.isEmpty() || correoEP.isEmpty() || espe.isEmpty() || disciplinas.isEmpty() ||   
            fechaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Detiene la ejecución si hay campos vacíos
        }
    }
    private void profesorNotFound(int idProfesor){
        Profesor profesor = controlProfesor.findProfesor(idProfesor);
    //alumnoNotFound();
    if (profesor == null) {
        JOptionPane.showMessageDialog(this, "No se encontró un alumno con el ID: " + idProfesor, "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtAPat = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtAMat = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        fechaNacChooser = new com.toedter.calendar.JDateChooser();
        jLabel7 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        txtCorreoE = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtContra = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtEspecialidad = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDisciplinas = new javax.swing.JTextArea();
        btnLimpiar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();

        jScrollPane1.setViewportView(jTree1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setPreferredSize(new java.awt.Dimension(700, 600));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(804, 0, -1, -1));

        jPanel2.setBackground(new java.awt.Color(33, 69, 113));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Registrar Profesor");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(199, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(196, 196, 196))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 90));

        jLabel2.setFont(new java.awt.Font("Poppins", 0, 18)); // NOI18N
        jLabel2.setText("Ingresa los datos que se solicitan a continuación: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel3.setText("Nombre:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, -1, -1));

        jLabel4.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel4.setText("Apellido Paterno:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        txtAPat.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtAPat.setBorder(null);
        txtAPat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtAPatMousePressed(evt);
            }
        });
        txtAPat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAPatActionPerformed(evt);
            }
        });
        getContentPane().add(txtAPat, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 370, 20));

        txtNombre.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtNombre.setBorder(null);
        txtNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtNombreMousePressed(evt);
            }
        });
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 370, 20));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel5.setText("Apellido Materno:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        txtAMat.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtAMat.setBorder(null);
        txtAMat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtAMatMousePressed(evt);
            }
        });
        txtAMat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAMatActionPerformed(evt);
            }
        });
        getContentPane().add(txtAMat, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 370, 20));

        jLabel6.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel6.setText("<html>Fecha de<br>nacimiento:</html> ");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, -1, -1));
        getContentPane().add(fechaNacChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 230, 370, 40));

        jLabel7.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel7.setText("Teléfono:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 290, -1, -1));

        txtTelefono.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtTelefono.setBorder(null);
        txtTelefono.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtTelefonoMousePressed(evt);
            }
        });
        txtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefonoActionPerformed(evt);
            }
        });
        getContentPane().add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 130, 20));

        txtCorreoE.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtCorreoE.setBorder(null);
        txtCorreoE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCorreoEMousePressed(evt);
            }
        });
        txtCorreoE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoEActionPerformed(evt);
            }
        });
        getContentPane().add(txtCorreoE, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 320, 370, 20));

        jLabel8.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel8.setText("Correo electrónico:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, -1, -1));

        txtContra.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        txtContra.setBorder(null);
        txtContra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtContraMousePressed(evt);
            }
        });
        txtContra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraActionPerformed(evt);
            }
        });
        getContentPane().add(txtContra, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, 370, 20));

        jLabel9.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel9.setText("Contraseña:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 350, -1, -1));

        jLabel10.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel10.setText("Especialidad:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 380, -1, -1));

        txtEspecialidad.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtEspecialidad.setBorder(null);
        txtEspecialidad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEspecialidadMousePressed(evt);
            }
        });
        txtEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEspecialidadActionPerformed(evt);
            }
        });
        getContentPane().add(txtEspecialidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 380, 370, 20));

        jLabel11.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel11.setText("<html>Disciplinas<br>impartidas:</html> ");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 410, -1, -1));

        txtDisciplinas.setColumns(20);
        txtDisciplinas.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        txtDisciplinas.setRows(5);
        jScrollPane2.setViewportView(txtDisciplinas);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 410, 370, 70));

        btnLimpiar.setBackground(new java.awt.Color(234, 69, 76));
        btnLimpiar.setFont(new java.awt.Font("Poppins", 1, 24)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpiar.setText("Limpiar");
        btnLimpiar.setBorderPainted(false);
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLimpiarMouseClicked(evt);
            }
        });
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 170, 130, -1));

        btnGuardar.setBackground(new java.awt.Color(234, 69, 76));
        btnGuardar.setFont(new java.awt.Font("Poppins", 1, 24)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar");
        btnGuardar.setBorderPainted(false);
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 240, -1, -1));

        jLabel12.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel12.setText("Edad:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, -1, -1));

        txtEdad.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txtEdad.setBorder(null);
        txtEdad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEdadMousePressed(evt);
            }
        });
        txtEdad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEdadActionPerformed(evt);
            }
        });
        getContentPane().add(txtEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 290, 130, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtAPatMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtAPatMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAPatMousePressed

    private void txtAPatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAPatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAPatActionPerformed

    private void txtNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNombreMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreMousePressed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtAMatMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtAMatMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAMatMousePressed

    private void txtAMatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAMatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAMatActionPerformed

    private void txtTelefonoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTelefonoMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefonoMousePressed

    private void txtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefonoActionPerformed

    private void txtCorreoEMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCorreoEMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoEMousePressed

    private void txtCorreoEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoEActionPerformed

    private void txtContraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtContraMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraMousePressed

    private void txtContraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraActionPerformed

    private void txtEspecialidadMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEspecialidadMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEspecialidadMousePressed

    private void txtEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEspecialidadActionPerformed
        
        
    }//GEN-LAST:event_txtEspecialidadActionPerformed

    private void btnLimpiarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarMouseClicked
        //javax.swing.JOptionPane.showMessageDialog(this,"Intento susario:\n "+jTextFieldCorreo2.getText(),String.valueOf(jPassword.getPassword())+"\n contrasenia: ");
        txtNombre.setText("");
        txtAMat.setText("");
        txtAPat.setText("");
        txtTelefono.setText("");
        txtContra.setText("");
        txtCorreoE.setText("");
        txtEspecialidad.setText("");
        txtDisciplinas.setText("");
        fechaNacChooser.setDate(null);

    }//GEN-LAST:event_btnLimpiarMouseClicked

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtNombre.setText("");
        txtAMat.setText("");
        txtAPat.setText("");
        txtTelefono.setText("");
        txtContra.setText("");
        txtCorreoE.setText("");
        txtEspecialidad.setText("");
        txtDisciplinas.setText("");
        fechaNacChooser.setDate(null);
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseClicked
        // TODO add your handling code here:
        String nombre = txtNombre.getText();
        String apPat = txtAPat.getText();
        String apMat = txtAMat.getText();
        String telefono = txtTelefono.getText();
        String contrasena = txtContra.getText();
        String correoEP = txtCorreoE.getText();
        String espe = txtEspecialidad.getText();
        String disciplinas = txtDisciplinas.getText(); // Asegúrate de que el campo sea correcto
        Date fechaSeleccionada = fechaNacChooser.getDate();
        int edad = Integer.parseInt(txtEdad.getText());
    }//GEN-LAST:event_btnGuardarMouseClicked

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // Obtener datos del formulario
        String nombre = txtNombre.getText().trim();
        String apPat = txtAPat.getText().trim();
        String apMat = txtAMat.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String contrasena = txtContra.getText().trim();
        String correoEP = txtCorreoE.getText().trim();
        String espe = txtEspecialidad.getText().trim();
        String disciplinas = txtDisciplinas.getText().trim(); // Asegúrate de que el campo sea correcto
        Date fechaSeleccionada = fechaNacChooser.getDate();
        int edad = Integer.parseInt(txtEdad.getText().trim());
        // Validaciones de campos vacíos
        if (nombre.isEmpty() || apPat.isEmpty() || apMat.isEmpty() || telefono.isEmpty() || 
            contrasena.isEmpty() || correoEP.isEmpty() || espe.isEmpty() || disciplinas.isEmpty() ||   
            fechaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Detiene la ejecución si hay campos vacíos
        }
        
        control.guardarProfe(nombre, apPat, apMat, fechaSeleccionada, telefono, contrasena, correoEP, espe, disciplinas, edad);
        JOptionPane optionPane = new JOptionPane("El profesor ha sido registrado.");
        optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog("Guardado exitoso");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);
           
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void txtEdadMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEdadMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEdadMousePressed

    private void txtEdadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEdadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEdadActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private com.toedter.calendar.JDateChooser fechaNacChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTree jTree1;
    private javax.swing.JTextField txtAMat;
    private javax.swing.JTextField txtAPat;
    private javax.swing.JTextField txtContra;
    private javax.swing.JTextField txtCorreoE;
    private javax.swing.JTextArea txtDisciplinas;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
