
package com.mycompany.megafitandfun.persistencia;

import com.mycompany.megafitandfun.logica.Clase;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.mycompany.megafitandfun.logica.Reserva;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.megafitandfun.logica.Dias;
import com.mycompany.megafitandfun.persistencia.exceptions.IllegalOrphanException;
import com.mycompany.megafitandfun.persistencia.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ClaseJpaController implements Serializable {

    public ClaseJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;
    
    public ClaseJpaController(){
        emf = Persistence.createEntityManagerFactory("fitandJPAPU");
    }
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void guardar(Clase clase) {
        if (clase.getReservas() == null) {
            clase.setReservas(new ArrayList<Reserva>());
        }
        if (clase.getDias() == null) {
            clase.setDias(new ArrayList<Dias>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<Reserva> attachedReservas = new ArrayList<Reserva>();
            for (Reserva reservasReservaToAttach : clase.getReservas()) {
                reservasReservaToAttach = em.getReference(reservasReservaToAttach.getClass(), reservasReservaToAttach.getIdReserva());
                attachedReservas.add(reservasReservaToAttach);
            }
            clase.setReservas(attachedReservas);
            List<Dias> attachedDias = new ArrayList<Dias>();
            for (Dias diasDiasToAttach : clase.getDias()) {
                diasDiasToAttach = em.getReference(diasDiasToAttach.getClass(), diasDiasToAttach.getIdDia());
                attachedDias.add(diasDiasToAttach);
            }
            clase.setDias(attachedDias);
            em.persist(clase);
            for (Reserva reservasReserva : clase.getReservas()) {
                Clase oldClaseOfReservasReserva = reservasReserva.getClase();
                reservasReserva.setClase(clase);
                reservasReserva = em.merge(reservasReserva);
                if (oldClaseOfReservasReserva != null) {
                    oldClaseOfReservasReserva.getReservas().remove(reservasReserva);
                    oldClaseOfReservasReserva = em.merge(oldClaseOfReservasReserva);
                }
            }
            for (Dias diasDias : clase.getDias()) {
                Clase oldClaseOfDiasDias = diasDias.getClase();
                diasDias.setClase(clase);
                diasDias = em.merge(diasDias);
                if (oldClaseOfDiasDias != null) {
                    oldClaseOfDiasDias.getDias().remove(diasDias);
                    oldClaseOfDiasDias = em.merge(oldClaseOfDiasDias);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Clase clase) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Clase persistentClase = em.find(Clase.class, clase.getIdClase());
            List<Reserva> reservasOld = persistentClase.getReservas();
            List<Reserva> reservasNew = clase.getReservas();
            List<Dias> diasOld = persistentClase.getDias();
            List<Dias> diasNew = clase.getDias();
            List<String> illegalOrphanMessages = null;
            for (Reserva reservasOldReserva : reservasOld) {
                if (!reservasNew.contains(reservasOldReserva)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Reserva " + reservasOldReserva + " since its clase field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Reserva> attachedReservasNew = new ArrayList<Reserva>();
            for (Reserva reservasNewReservaToAttach : reservasNew) {
                reservasNewReservaToAttach = em.getReference(reservasNewReservaToAttach.getClass(), reservasNewReservaToAttach.getIdReserva());
                attachedReservasNew.add(reservasNewReservaToAttach);
            }
            reservasNew = attachedReservasNew;
            clase.setReservas(reservasNew);
            List<Dias> attachedDiasNew = new ArrayList<Dias>();
            for (Dias diasNewDiasToAttach : diasNew) {
                diasNewDiasToAttach = em.getReference(diasNewDiasToAttach.getClass(), diasNewDiasToAttach.getIdDia());
                attachedDiasNew.add(diasNewDiasToAttach);
            }
            diasNew = attachedDiasNew;
            clase.setDias(diasNew);
            clase = em.merge(clase);
            for (Reserva reservasNewReserva : reservasNew) {
                if (!reservasOld.contains(reservasNewReserva)) {
                    Clase oldClaseOfReservasNewReserva = reservasNewReserva.getClase();
                    reservasNewReserva.setClase(clase);
                    reservasNewReserva = em.merge(reservasNewReserva);
                    if (oldClaseOfReservasNewReserva != null && !oldClaseOfReservasNewReserva.equals(clase)) {
                        oldClaseOfReservasNewReserva.getReservas().remove(reservasNewReserva);
                        oldClaseOfReservasNewReserva = em.merge(oldClaseOfReservasNewReserva);
                    }
                }
            }
            for (Dias diasOldDias : diasOld) {
                if (!diasNew.contains(diasOldDias)) {
                    diasOldDias.setClase(null);
                    diasOldDias = em.merge(diasOldDias);
                }
            }
            for (Dias diasNewDias : diasNew) {
                if (!diasOld.contains(diasNewDias)) {
                    Clase oldClaseOfDiasNewDias = diasNewDias.getClase();
                    diasNewDias.setClase(clase);
                    diasNewDias = em.merge(diasNewDias);
                    if (oldClaseOfDiasNewDias != null && !oldClaseOfDiasNewDias.equals(clase)) {
                        oldClaseOfDiasNewDias.getDias().remove(diasNewDias);
                        oldClaseOfDiasNewDias = em.merge(oldClaseOfDiasNewDias);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = clase.getIdClase();
                if (findClase(id) == null) {
                    throw new NonexistentEntityException("The clase with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Clase clase;
            try {
                clase = em.getReference(Clase.class, id);
                clase.getIdClase();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The clase with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Reserva> reservasOrphanCheck = clase.getReservas();
            for (Reserva reservasOrphanCheckReserva : reservasOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Clase (" + clase + ") cannot be destroyed since the Reserva " + reservasOrphanCheckReserva + " in its reservas field has a non-nullable clase field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Dias> dias = clase.getDias();
            for (Dias diasDias : dias) {
                diasDias.setClase(null);
                diasDias = em.merge(diasDias);
            }
            em.remove(clase);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Clase> findClaseEntities() {
        return findClaseEntities(true, -1, -1);
    }

    public List<Clase> findClaseEntities(int maxResults, int firstResult) {
        return findClaseEntities(false, maxResults, firstResult);
    }

    private List<Clase> findClaseEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Clase.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Clase findClase(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Clase.class, id);
        } finally {
            em.close();
        }
    }

    public List<Clase> findClasesByDisciplina(String disciplina) {
    EntityManager em = getEntityManager();
    try {
        // Consulta JPQL para buscar clases por disciplina
        Query query = em.createQuery("SELECT c FROM Clase c WHERE c.disciplina LIKE :disciplina", Clase.class);
        query.setParameter("disciplina", "%" + disciplina + "%"); // Búsqueda parcial
        return query.getResultList();
    } finally {
        em.close();
        }
    }
    
    public Integer findProfesorIdByClaseId(Integer idClase) {
        EntityManager em = getEntityManager();
        try {
            // Consulta JPQL para obtener el ID del profesor asociado a la clase
            Query query = em.createQuery(
                "SELECT c.profesor.idProfesor FROM Clase c WHERE c.idClase = :idClase"
            );
            query.setParameter("idClase", idClase);

            // Devuelve el ID del profesor
            return (Integer) query.getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Retorna null si no encuentra resultados o ocurre un error
        } finally {
            em.close();
        }
    }

    
    public int getClaseCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Clase> rt = cq.from(Clase.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
