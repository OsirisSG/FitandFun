
package com.mycompany.megafitandfun.persistencia;

import com.mycompany.megafitandfun.logica.Alumno;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.mycompany.megafitandfun.logica.Pago;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.megafitandfun.logica.Reserva;
import com.mycompany.megafitandfun.persistencia.exceptions.IllegalOrphanException;
import com.mycompany.megafitandfun.persistencia.exceptions.NonexistentEntityException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author dayra
 */
public class AlumnoJpaController implements Serializable {

    public AlumnoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;
    
    public AlumnoJpaController(){
        emf = Persistence.createEntityManagerFactory("fitandJPAPU");
    }


    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Alumno alumno) {
        if (alumno.getPagos() == null) {
            alumno.setPagos(new ArrayList<Pago>());
        }
        if (alumno.getReservas() == null) {
            alumno.setReservas(new ArrayList<Reserva>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<Pago> attachedPagos = new ArrayList<Pago>();
            for (Pago pagosPagoToAttach : alumno.getPagos()) {
                pagosPagoToAttach = em.getReference(pagosPagoToAttach.getClass(), pagosPagoToAttach.getIdPago());
                attachedPagos.add(pagosPagoToAttach);
            }
            alumno.setPagos(attachedPagos);
            List<Reserva> attachedReservas = new ArrayList<Reserva>();
            for (Reserva reservasReservaToAttach : alumno.getReservas()) {
                reservasReservaToAttach = em.getReference(reservasReservaToAttach.getClass(), reservasReservaToAttach.getIdReserva());
                attachedReservas.add(reservasReservaToAttach);
            }
            alumno.setReservas(attachedReservas);
            em.persist(alumno);
            for (Pago pagosPago : alumno.getPagos()) {
                Alumno oldAlumnoOfPagosPago = pagosPago.getAlumno();
                pagosPago.setAlumno(alumno);
                pagosPago = em.merge(pagosPago);
                if (oldAlumnoOfPagosPago != null) {
                    oldAlumnoOfPagosPago.getPagos().remove(pagosPago);
                    oldAlumnoOfPagosPago = em.merge(oldAlumnoOfPagosPago);
                }
            }
            for (Reserva reservasReserva : alumno.getReservas()) {
                Alumno oldAlumnoOfReservasReserva = reservasReserva.getAlumno();
                reservasReserva.setAlumno(alumno);
                reservasReserva = em.merge(reservasReserva);
                if (oldAlumnoOfReservasReserva != null) {
                    oldAlumnoOfReservasReserva.getReservas().remove(reservasReserva);
                    oldAlumnoOfReservasReserva = em.merge(oldAlumnoOfReservasReserva);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Alumno alumno) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Alumno persistentAlumno = em.find(Alumno.class, alumno.getIdAlumno());
            List<Pago> pagosOld = persistentAlumno.getPagos();
            List<Pago> pagosNew = alumno.getPagos();
            List<Reserva> reservasOld = persistentAlumno.getReservas();
            List<Reserva> reservasNew = alumno.getReservas();
            List<String> illegalOrphanMessages = null;
            for (Reserva reservasOldReserva : reservasOld) {
                if (!reservasNew.contains(reservasOldReserva)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Reserva " + reservasOldReserva + " since its alumno field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Pago> attachedPagosNew = new ArrayList<Pago>();
            for (Pago pagosNewPagoToAttach : pagosNew) {
                pagosNewPagoToAttach = em.getReference(pagosNewPagoToAttach.getClass(), pagosNewPagoToAttach.getIdPago());
                attachedPagosNew.add(pagosNewPagoToAttach);
            }
            pagosNew = attachedPagosNew;
            alumno.setPagos(pagosNew);
            List<Reserva> attachedReservasNew = new ArrayList<Reserva>();
            for (Reserva reservasNewReservaToAttach : reservasNew) {
                reservasNewReservaToAttach = em.getReference(reservasNewReservaToAttach.getClass(), reservasNewReservaToAttach.getIdReserva());
                attachedReservasNew.add(reservasNewReservaToAttach);
            }
            reservasNew = attachedReservasNew;
            alumno.setReservas(reservasNew);
            alumno = em.merge(alumno);
            for (Pago pagosOldPago : pagosOld) {
                if (!pagosNew.contains(pagosOldPago)) {
                    pagosOldPago.setAlumno(null);
                    pagosOldPago = em.merge(pagosOldPago);
                }
            }
            for (Pago pagosNewPago : pagosNew) {
                if (!pagosOld.contains(pagosNewPago)) {
                    Alumno oldAlumnoOfPagosNewPago = pagosNewPago.getAlumno();
                    pagosNewPago.setAlumno(alumno);
                    pagosNewPago = em.merge(pagosNewPago);
                    if (oldAlumnoOfPagosNewPago != null && !oldAlumnoOfPagosNewPago.equals(alumno)) {
                        oldAlumnoOfPagosNewPago.getPagos().remove(pagosNewPago);
                        oldAlumnoOfPagosNewPago = em.merge(oldAlumnoOfPagosNewPago);
                    }
                }
            }
            for (Reserva reservasNewReserva : reservasNew) {
                if (!reservasOld.contains(reservasNewReserva)) {
                    Alumno oldAlumnoOfReservasNewReserva = reservasNewReserva.getAlumno();
                    reservasNewReserva.setAlumno(alumno);
                    reservasNewReserva = em.merge(reservasNewReserva);
                    if (oldAlumnoOfReservasNewReserva != null && !oldAlumnoOfReservasNewReserva.equals(alumno)) {
                        oldAlumnoOfReservasNewReserva.getReservas().remove(reservasNewReserva);
                        oldAlumnoOfReservasNewReserva = em.merge(oldAlumnoOfReservasNewReserva);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = alumno.getIdAlumno();
                if (findAlumno(id) == null) {
                    throw new NonexistentEntityException("The alumno with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Alumno alumno;
            try {
                alumno = em.getReference(Alumno.class, id);
                alumno.getIdAlumno();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The alumno with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Reserva> reservasOrphanCheck = alumno.getReservas();
            for (Reserva reservasOrphanCheckReserva : reservasOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Alumno (" + alumno + ") cannot be destroyed since the Reserva " + reservasOrphanCheckReserva + " in its reservas field has a non-nullable alumno field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Pago> pagos = alumno.getPagos();
            for (Pago pagosPago : pagos) {
                pagosPago.setAlumno(null);
                pagosPago = em.merge(pagosPago);
            }
            em.remove(alumno);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Alumno> findAlumnoEntities() {
        return findAlumnoEntities(true, -1, -1);
    }

    public List<Alumno> findAlumnoEntities(int maxResults, int firstResult) {
        return findAlumnoEntities(false, maxResults, firstResult);
    }

    private List<Alumno> findAlumnoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Alumno.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Alumno findAlumno(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Alumno.class, id);
        } finally {
            em.close();
        }
    }

    public List<Alumno> findAlumnosByNombre(String nombre) {
        EntityManager em = getEntityManager();
        try {
            // Crear la consulta JPQL para buscar alumnos por nombre
            Query query = em.createQuery("SELECT a FROM Alumno a WHERE a.nombre LIKE :nombre", Alumno.class);
            query.setParameter("nombre", "%" + nombre + "%"); // Búsqueda parcial
            return query.getResultList(); // Retorna una lista de alumnos
        } finally {
            em.close(); // Asegurar que el EntityManager se cierre
        }
    }

    public String findEmailById(int idAlumno) {
        EntityManager em = getEntityManager();
        try {
            Alumno alumno = em.find(Alumno.class, idAlumno);
            return (alumno != null) ? alumno.getEmail() : null;
        } finally {
            em.close();
        }
    }
    
    public int getAlumnoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Alumno> rt = cq.from(Alumno.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
