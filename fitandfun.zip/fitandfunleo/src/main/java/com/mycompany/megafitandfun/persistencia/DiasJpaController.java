
package com.mycompany.megafitandfun.persistencia;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.mycompany.megafitandfun.logica.Clase;
import com.mycompany.megafitandfun.logica.Dias;
import com.mycompany.megafitandfun.persistencia.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DiasJpaController implements Serializable {

    public DiasJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;
    
    public DiasJpaController(){
        emf = Persistence.createEntityManagerFactory("fitandJPAPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Dias dias) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Clase clase = dias.getClase();
            if (clase != null) {
                clase = em.getReference(clase.getClass(), clase.getIdClase());
                dias.setClase(clase);
            }
            em.persist(dias);
            if (clase != null) {
                clase.getDias().add(dias);
                clase = em.merge(clase);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Dias dias) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Dias persistentDias = em.find(Dias.class, dias.getIdDia());
            Clase claseOld = persistentDias.getClase();
            Clase claseNew = dias.getClase();
            if (claseNew != null) {
                claseNew = em.getReference(claseNew.getClass(), claseNew.getIdClase());
                dias.setClase(claseNew);
            }
            dias = em.merge(dias);
            if (claseOld != null && !claseOld.equals(claseNew)) {
                claseOld.getDias().remove(dias);
                claseOld = em.merge(claseOld);
            }
            if (claseNew != null && !claseNew.equals(claseOld)) {
                claseNew.getDias().add(dias);
                claseNew = em.merge(claseNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = dias.getIdDia();
                if (findDias(id) == null) {
                    throw new NonexistentEntityException("The dias with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Dias dias;
            try {
                dias = em.getReference(Dias.class, id);
                dias.getIdDia();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The dias with id " + id + " no longer exists.", enfe);
            }
            Clase clase = dias.getClase();
            if (clase != null) {
                clase.getDias().remove(dias);
                clase = em.merge(clase);
            }
            em.remove(dias);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Dias> findDiasEntities() {
        return findDiasEntities(true, -1, -1);
    }

    public List<Dias> findDiasEntities(int maxResults, int firstResult) {
        return findDiasEntities(false, maxResults, firstResult);
    }

    private List<Dias> findDiasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Dias.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Dias findDias(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Dias.class, id);
        } finally {
            em.close();
        }
    }

    public int getDiasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Dias> rt = cq.from(Dias.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
