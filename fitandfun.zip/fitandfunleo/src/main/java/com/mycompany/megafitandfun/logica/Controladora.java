package com.mycompany.megafitandfun.logica;
import com.mycompany.megafitandfun.persistencia.ControladoraPersistencia;
import java.io.File;
import java.util.Date;
import java.util.List;

public class Controladora {
    ControladoraPersistencia controlPersis = new ControladoraPersistencia();

    public void guardarProfe(String nombre, String apPat, String apMat, Date fechaSeleccionada, String telefono, String contrasena, String correoEP, String espe, String disciplinas, int edad) {
        
        Profesor profe = new Profesor();
        profe.setNombre(nombre);
        profe.setApPat(apPat);
        profe.setApMat(apMat);
        profe.setTelefono(telefono);
        profe.setFechaNac(fechaSeleccionada);
        profe.setEdad(edad);
        profe.setEmail(correoEP);
        profe.setPassword(contrasena);
        profe.setEspecialidad(espe);
        profe.setDisciplinas(disciplinas);
        
        controlPersis.saveProfe(profe);
    }
    
public void guardarAlumno(String nombre, String apPat, String apMat, String domicilio, Date fechaSeleccionada, String telefono, String contrasena, String correoEP, String aspiraciones, double peso, double estatura, int edad, String padecimientos, String est, String esc, String carrera, String profesion, String lugartrab, String puesto, File certMed, Date fechaInscripcion) {
        
        Alumno alumno = new Alumno();
        alumno.setNombre(nombre);
        alumno.setApPat(apPat);
        alumno.setApMat(apMat);
        alumno.setDomicilio(domicilio);
        alumno.setTelefono(telefono);
        alumno.setFechaNac(fechaSeleccionada);
        alumno.setEdad(edad);
        alumno.setEmail(correoEP);
        alumno.setPassword(contrasena);
        //alumno.setFechaIngreso(fechaIngreso);
        alumno.setAspiraciones(aspiraciones);
        alumno.setPeso(peso);
        alumno.setEstatura(estatura);
        //alumno.setCertificadoMedico(Boolean.FALSE);
        alumno.setPadecimiento(padecimientos);
        alumno.setNivelEstudios(Alumno.NivelEstudios.valueOf(est));  //Tienene que escribirlo en mayusculas
        alumno.setInstitucion(esc);
        alumno.setCarrera(carrera);
        alumno.setProfesion(profesion);
        alumno.setLugarTrabajo(lugartrab);
        alumno.setPuesto(puesto);
       // alumno.setEspecialidad(espe);
        //alumno.setDisciplinas(disciplinas);
        alumno.setCertificadoMedico(certMed);
        alumno.setFechaIngreso(fechaInscripcion);
        
        controlPersis.saveAlumno(alumno);
    }
    
    public List<Alumno> buscarAlumnosPorNombre(String nombre) {
        return controlPersis.buscarAlumnosPorNombre(nombre);
    }
    
    public void eliminarAlumno(int id){
        controlPersis.eliminarAlumno(id);
    }
    
    public List<Profesor> buscarProfesoresPorNombre(String nombre) {
        return controlPersis.buscarProfesoresPorNombre(nombre);
    }
    
    public void eliminarProfesor(int id){
        controlPersis.eliminarProfesor(id);
    }
}
