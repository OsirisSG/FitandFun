package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.logica.Avance;
import com.mycompany.megafitandfun.logica.Clase;
import com.mycompany.megafitandfun.logica.Profesor;
import com.mycompany.megafitandfun.persistencia.AvanceJpaController;
import com.mycompany.megafitandfun.persistencia.ClaseJpaController;
import com.mycompany.megafitandfun.persistencia.ProfesorJpaController;
import java.util.Date;
import java.util.List;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Ui_VerAvancesWindow extends javax.swing.JFrame {
ClaseJpaController controlClase = new ClaseJpaController();
ProfesorJpaController controlProfe;
AvanceJpaController controlAvance;
int id;
Avance avance;
    public Ui_VerAvancesWindow(int idUsuario) {
        initComponents();
        this.id = idUsuario;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnBuscarClase = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtIDClase = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtBusClase = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAvance = new javax.swing.JTextArea();
        txtLink = new javax.swing.JTextField();
        btnPDF = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnAvances = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(33, 69, 113));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Ver Avances");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        btnBuscarClase.setBackground(new java.awt.Color(234, 69, 76));
        btnBuscarClase.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        btnBuscarClase.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarClase.setText("Buscar Clase");
        btnBuscarClase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarClaseActionPerformed(evt);
            }
        });

        jLabel2.setText("ID Clase: ");

        txtIDClase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIDClaseActionPerformed(evt);
            }
        });

        txtBusClase.setColumns(20);
        txtBusClase.setRows(5);
        jScrollPane1.setViewportView(txtBusClase);

        txtAvance.setColumns(20);
        txtAvance.setRows(5);
        jScrollPane2.setViewportView(txtAvance);

        btnPDF.setBackground(new java.awt.Color(234, 69, 76));
        btnPDF.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        btnPDF.setForeground(new java.awt.Color(255, 255, 255));
        btnPDF.setText("Ver PDF");
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });

        jLabel3.setText("Avance o Recomendacion:");

        jLabel4.setText("Link:");

        jLabel5.setText("pdf:");

        btnAvances.setBackground(new java.awt.Color(234, 69, 76));
        btnAvances.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        btnAvances.setForeground(new java.awt.Color(255, 255, 255));
        btnAvances.setText("Cargar Avances");
        btnAvances.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvancesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPDF)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane2)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtIDClase, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnBuscarClase))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(25, 25, 25)
                                    .addComponent(btnAvances)))
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(txtLink))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBuscarClase)
                            .addComponent(jLabel2)
                            .addComponent(txtIDClase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAvances))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(11, 11, 11)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(1, 1, 1)
                .addComponent(txtLink, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPDF)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIDClaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIDClaseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIDClaseActionPerformed

    private void btnBuscarClaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarClaseActionPerformed
                txtBusClase.setText("");
    
    // Solicitar el nombre del alumno a buscar
    String nombreBuscar = JOptionPane.showInputDialog("Dame la Disciplina de la clase a buscar");

    // Validar que se haya ingresado un nombre
    if (nombreBuscar == null || nombreBuscar.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingresa un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Llamar al controlador para obtener la lista de alumnos
    List<Clase> clasesEncontradas = controlClase.findClasesByDisciplina(nombreBuscar);

    // Verificar si se encontraron alumnos
    if (!clasesEncontradas.isEmpty()) {
        txtBusClase.append("Clases encontradas con el nombre: " + nombreBuscar + "\n\n");
        for (Clase clase : clasesEncontradas) {
            txtBusClase.append("Nombre: " + clase.getDisciplina() + "\n");
            txtBusClase.append("ID: " + clase.getIdClase() + "\n");
            txtBusClase.append("-------------------------------------------\n");
        }
    } else {
        txtBusClase.append("No se encontraron clases con el nombre: " + nombreBuscar + "\n");
    }
    }//GEN-LAST:event_btnBuscarClaseActionPerformed

    private void btnAvancesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvancesActionPerformed
    // Obtener los valores de los campos
    String idC = txtIDClase.getText().trim();
    int idAlumno = id;  // Este valor debe estar definido anteriormente en tu código

    // Obtener la fecha actual
    Date fecha = new Date();

    // Validar que no haya campos vacíos
    if (idC.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Detiene la ejecución si hay campos vacíos
    }

    // Validar y convertir el ID del profesor y el cupo
    int idClase;
    try {
        idClase = Integer.parseInt(idC); // Convertir el cupo a entero
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El ID del profesor y el cupo deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Detiene la ejecución si los valores no son válidos
    }

    int idProfe;
    idProfe = controlClase.findProfesorIdByClaseId(idClase);  // Buscar el ID del profesor relacionado con la clase
    Profesor prof = controlProfe.findProfesor(idProfe);  // Obtener el objeto Profesor

    // Buscar el avance para el alumno y profesor
    avance = controlAvance.findAvanceByProfesorAndAlumno(prof, idAlumno);

    // Si el avance no es nulo o vacío, ponerlo en el campo txtAvance
    if (avance != null) {
        if (avance.getComentario() != null && !avance.getComentario().isEmpty()) {
            txtAvance.setText(avance.getComentario());
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró ningún avance para este alumno.", "Información", JOptionPane.INFORMATION_MESSAGE);
        }

        // Si el avance tiene un link de video, ponerlo en el campo txtLink
        if (avance.getLinkVideo() != null && !avance.getLinkVideo().isEmpty()) {
            txtLink.setText(avance.getLinkVideo());
        }


    } else {
        // Si no se encuentra un avance, mostrar un mensaje
        JOptionPane.showMessageDialog(this, "No se encontró ningún avance para este alumno.", "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    }//GEN-LAST:event_btnAvancesActionPerformed

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPDFActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAvances;
    private javax.swing.JButton btnBuscarClase;
    private javax.swing.JButton btnPDF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea txtAvance;
    private javax.swing.JTextArea txtBusClase;
    private javax.swing.JTextField txtIDClase;
    private javax.swing.JTextField txtLink;
    // End of variables declaration//GEN-END:variables
}
