package com.mycompany.megafitandfun.logica;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Admi implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int idAdmin;

    @Basic
    private String nombre_Ad;
    private String ap_P_Ad;
    private String ap_M_Ad;
    private String email_Ad;
    private String contra_Ad;


    // Constructor sin parámetros (requerido por JPA)
    public Admi() {
    }

    public Admi(int idAdmin, String nombre_Ad, String ap_P_Ad, String ap_M_Ad, String email_Ad, String contra_Ad) {
        this.idAdmin = idAdmin;
        this.nombre_Ad = nombre_Ad;
        this.ap_P_Ad = ap_P_Ad;
        this.ap_M_Ad = ap_M_Ad;
        this.email_Ad = email_Ad;
        this.contra_Ad = contra_Ad;
    }

    public int getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }

    public String getNombre_Ad() {
        return nombre_Ad;
    }

    public void setNombre_Ad(String nombre_Ad) {
        this.nombre_Ad = nombre_Ad;
    }

    public String getAp_P_Ad() {
        return ap_P_Ad;
    }

    public void setAp_P_Ad(String ap_P_Ad) {
        this.ap_P_Ad = ap_P_Ad;
    }

    public String getAp_M_Ad() {
        return ap_M_Ad;
    }

    public void setAp_M_Ad(String ap_M_Ad) {
        this.ap_M_Ad = ap_M_Ad;
    }

    public String getEmail_Ad() {
        return email_Ad;
    }

    public void setEmail_Ad(String email_Ad) {
        this.email_Ad = email_Ad;
    }

    public String getContra_Ad() {
        return contra_Ad;
    }

    public void setContra_Ad(String contra_Ad) {
        this.contra_Ad = contra_Ad;
    }
    
    
}
