package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.Sesion;
import com.mycompany.megafitandfun.logica.Clase;
import com.mycompany.megafitandfun.persistencia.ClaseJpaController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Ui_ReservarClaseWindow extends javax.swing.JFrame {
    // Conexión a la base de datos
    String url = "jdbc:mysql://localhost:3306/bdfitandfun"; // Cambia por tu base de datos
    String usuarioBD = "root"; // Usuario de la base de datos
    String passwordBD = ""; // Contraseña de la base de datos
    ClaseJpaController controlClase = new ClaseJpaController();
    public Ui_ReservarClaseWindow(int idUsuario) {
        initComponents();
       // verClase();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnGuardarReserva = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtIDClase = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaClases = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(700, 600));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(33, 69, 113));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Reservar Clase");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(206, 206, 206))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        btnGuardarReserva.setBackground(new java.awt.Color(234, 69, 76));
        btnGuardarReserva.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        btnGuardarReserva.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardarReserva.setText("Reservar");
        btnGuardarReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarReservaActionPerformed(evt);
            }
        });

        btnBuscar.setBackground(new java.awt.Color(234, 69, 76));
        btnBuscar.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel4.setText("Ingresa los valores solicitados:");

        jLabel2.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel2.setText("ID clase:");

        tablaClases.setAutoCreateRowSorter(true);
        tablaClases.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        tablaClases.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaClases.setGridColor(new java.awt.Color(255, 255, 255));
        tablaClases.setPreferredSize(new java.awt.Dimension(320, 80));
        tablaClases.setRowHeight(30);
        tablaClases.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(tablaClases);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 641, Short.MAX_VALUE))
                .addGap(26, 26, 26))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtIDClase, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnBuscar)
                .addGap(67, 67, 67))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(254, 254, 254)
                .addComponent(btnGuardarReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIDClase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(btnBuscar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(btnGuardarReserva)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarReservaActionPerformed
        realizarReserva();
    }//GEN-LAST:event_btnGuardarReservaActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        verClase();
    
    }//GEN-LAST:event_btnBuscarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnGuardarReserva;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaClases;
    private javax.swing.JTextField txtIDClase;
    // End of variables declaration//GEN-END:variables

    private void verClase() {
         String idC = txtIDClase.getText();  // Obtiene el id de la clase desde el campo de texto

    try {
        // Conexión a la base de datos
        Connection con = DriverManager.getConnection(url, usuarioBD, passwordBD);

        // Consulta SQL para obtener la clase según el id
        String query = "SELECT idclase, disciplina, fecha, horario, cupomaximo FROM clase WHERE idclase = ?";
        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1, idC);  // Establece el valor del parámetro de la consulta

        // Ejecuta la consulta
        ResultSet rs = pst.executeQuery();

        // Crear un modelo de tabla para mostrar los datos
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Clase");
        model.addColumn("Disciplina");
        model.addColumn("Fecha");
        model.addColumn("Horario");
        model.addColumn("Cupo Disponible");

        // Llenar la tabla con los datos de la base de datos
        if (rs.next()) {  // Comprobamos si se encontró alguna clase
            Vector<Object> row = new Vector<>();
            row.add(rs.getInt("idclase"));           // ID de la clase
            row.add(rs.getString("disciplina"));     // Disciplina (nombre de la clase)
            row.add(rs.getDate("fecha"));            // Fecha de la clase
            row.add(rs.getTime("horario"));          // Hora de la clase
            row.add(rs.getInt("cupomaximo"));        // Cupo disponible para la clase
            model.addRow(row);
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró la clase con ID: " + idC);
        }

        // Establecer el modelo de la tabla
        tablaClases.setModel(model);

        // Cerrar la conexión
        con.close();
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar la clase.");
    }

    }

    private void realizarReserva() {
        String idClase = txtIDClase.getText();  // ID de la clase a reservar
        int idUsuarioInt = Sesion.getIdUsuario();
       String tipoUsuario = Sesion.getTipoUsuario();
       String idUsuario =  String.valueOf(idUsuarioInt);  // ID del usuario que hace la reserva

        try (Connection con = DriverManager.getConnection(url, usuarioBD, passwordBD)) {
            // Obtener la información de la clase
            String queryClase = "SELECT cupomaximo, fecha FROM clase WHERE idclase = ?";
            PreparedStatement pstClase = con.prepareStatement(queryClase);
            pstClase.setString(1, idClase);
            ResultSet rsClase = pstClase.executeQuery();

            if (rsClase.next()) {
                int cupoMaximo = rsClase.getInt("cupomaximo");
                Date fechaClase = rsClase.getDate("fecha");

                // Verificar disponibilidad de cupo
                String queryReserva = "SELECT COUNT(*) FROM reserva WHERE idclase = ?";
                PreparedStatement pstReserva = con.prepareStatement(queryReserva);
                pstReserva.setString(1, idClase);
                ResultSet rsReserva = pstReserva.executeQuery();
                rsReserva.next();
                int reservasRealizadas = rsReserva.getInt(1);

                if (reservasRealizadas >= cupoMaximo) {
                    JOptionPane.showMessageDialog(this, "No hay cupo disponible para esta clase.");
                    return;
                }

                // Verificar que la reserva sea al menos un día antes de la clase
                long tiempoRestante = fechaClase.getTime() - System.currentTimeMillis();
                long unDia = 24 * 60 * 60 * 1000;  // Un día en milisegundos

                if (tiempoRestante < unDia) {
                    JOptionPane.showMessageDialog(this, "Debe hacer la reserva al menos un día antes de la clase.");
                    return;
                }

                // Realizar la reserva
                String queryInsert = "INSERT INTO reserva (idclase, idalumno, fechareserva, estado) VALUES (?, ?, NOW(), 'reservada')";
                PreparedStatement pstInsert = con.prepareStatement(queryInsert);
                pstInsert.setString(1, idClase);
                pstInsert.setString(2, idUsuario);
                pstInsert.executeUpdate();

                JOptionPane.showMessageDialog(this, "Reserva realizada con éxito.");

            } else {
                JOptionPane.showMessageDialog(this, "La clase no existe.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al realizar la reserva.");
        }
    }

}
