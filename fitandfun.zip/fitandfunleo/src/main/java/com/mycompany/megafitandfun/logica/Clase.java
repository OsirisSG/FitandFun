
package com.mycompany.megafitandfun.logica;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Clase implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idClase;
    
    private String horario;
    private String disciplina;
    private String descripcion;
    private Integer cupoMaximo;
    private Integer inscritos;
    
    @Temporal(TemporalType.DATE)
    private Date fecha;
    
    @ManyToOne
    @JoinColumn(name = "idProfesor")
    private Profesor profesor;

    @OneToMany(mappedBy = "clase", cascade = CascadeType.ALL)
    private List<Reserva> reservas;

    @OneToMany(mappedBy = "clase", cascade = CascadeType.ALL)
    private List<Dias> dias;

    // Getters y Setters

    public Clase() {
    }

    public Clase(Date fecha, String horario, String disciplina, String descripcion, Integer cupoMaximo, Profesor profesor) {
        this.idClase = idClase;
        this.fecha = fecha;
        this.horario = horario;
        this.disciplina = disciplina;
        this.descripcion = descripcion;
        this.cupoMaximo = cupoMaximo;
        this.inscritos = inscritos;
        this.profesor = profesor;
    }
    
    public Clase(Integer idClase, Date fecha, String horario, String disciplina, String descripcion, Integer cupoMaximo, Integer inscritos, Profesor profesor, List<Reserva> reservas, List<Dias> dias) {
        this.idClase = idClase;
        this.fecha = fecha;
        this.horario = horario;
        this.disciplina = disciplina;
        this.descripcion = descripcion;
        this.cupoMaximo = cupoMaximo;
        this.inscritos = inscritos;
        this.profesor = profesor;
        this.reservas = reservas;
        this.dias = dias;
    }

    public Integer getIdClase() {
        return idClase;
    }

    public void setIdClase(Integer idClase) {
        this.idClase = idClase;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getCupoMaximo() {
        return cupoMaximo;
    }

    public void setCupoMaximo(Integer cupoMaximo) {
        this.cupoMaximo = cupoMaximo;
    }

    public Integer getInscritos() {
        return inscritos;
    }

    public void setInscritos(Integer inscritos) {
        this.inscritos = inscritos;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(List<Reserva> reservas) {
        this.reservas = reservas;
    }

    public List<Dias> getDias() {
        return dias;
    }

    public void setDias(List<Dias> dias) {
        this.dias = dias;
    }
    
}