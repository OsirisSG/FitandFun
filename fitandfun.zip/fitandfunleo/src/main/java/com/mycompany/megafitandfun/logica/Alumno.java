package com.mycompany.megafitandfun.logica;
import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Alumno implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idAlumno;

    private String nombre;
    private String apPat;
    private String apMat;
    private String domicilio;
    private String telefono;
    private Integer edad;
    private String email;
    private String password;  
    private String aspiraciones;
    @Temporal(TemporalType.DATE)
    private Date fechaIngreso;
    @Temporal(TemporalType.DATE)
    private Date fechaNac;
    // Campos de salud
    private Double peso;
    private Double estatura;
    private File certificadoMedico;
    private String padecimiento;

    // Campos de educación
    @Enumerated(EnumType.STRING)
    private NivelEstudios nivelEstudios;
    private String institucion;
    private String carrera;
    private String profesion;
    private String lugarTrabajo;
    private String puesto;

    @OneToMany(mappedBy = "alumno", cascade = CascadeType.ALL)
    private List<Pago> pagos;

    @OneToMany(mappedBy = "alumno", cascade = CascadeType.ALL)
    private List<Reserva> reservas;

    public enum NivelEstudios {
        PRIMARIA, SECUNDARIA, PREPARATORIA, LICENCIATURA, MAESTRIA, DOCTORADO
    }

    // Getters y Setters

    public Alumno() {
    }

    public Alumno(Integer idAlumno, String nombre, String apPat, String apMat, String domicilio, String telefono, Date fechaNac, Integer edad, String email, String password, Date fechaIngreso, String aspiraciones, Double peso, Double estatura, File certificadoMedico, String padecimiento, NivelEstudios nivelEstudios, String institucion, String carrera, String profesion, String lugarTrabajo, String puesto, List<Pago> pagos, List<Reserva> reservas) {
        this.idAlumno = idAlumno;
        this.nombre = nombre;
        this.apPat = apPat;
        this.apMat = apMat;
        this.domicilio = domicilio;
        this.telefono = telefono;
        this.fechaNac = fechaNac;
        this.edad = edad;
        this.email = email;
        this.password = password;
        this.fechaIngreso = fechaIngreso;
        this.aspiraciones = aspiraciones;
        this.peso = peso;
        this.estatura = estatura;
        this.certificadoMedico = certificadoMedico;
        this.padecimiento = padecimiento;
        this.nivelEstudios = nivelEstudios;
        this.institucion = institucion;
        this.carrera = carrera;
        this.profesion = profesion;
        this.lugarTrabajo = lugarTrabajo;
        this.puesto = puesto;
        this.pagos = pagos;
        this.reservas = reservas;
    }

    public Integer getIdAlumno() {
        return idAlumno;
    }

    public void setIdAlumno(Integer idAlumno) {
        this.idAlumno = idAlumno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPat() {
        return apPat;
    }

    public void setApPat(String apPat) {
        this.apPat = apPat;
    }

    public String getApMat() {
        return apMat;
    }

    public void setApMat(String apMat) {
        this.apMat = apMat;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(Date fechaNac) {
        this.fechaNac = fechaNac;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getAspiraciones() {
        return aspiraciones;
    }

    public void setAspiraciones(String aspiraciones) {
        this.aspiraciones = aspiraciones;
    }

    public Double getPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    public Double getEstatura() {
        return estatura;
    }

    public void setEstatura(Double estatura) {
        this.estatura = estatura;
    }

    public File getCertificadoMedico() {
        return certificadoMedico;
    }

    public void setCertificadoMedico(File certificadoMedico) {
        this.certificadoMedico = certificadoMedico;
    }

    public String getPadecimiento() {
        return padecimiento;
    }

    public void setPadecimiento(String padecimiento) {
        this.padecimiento = padecimiento;
    }

    public NivelEstudios getNivelEstudios() {
        return nivelEstudios;
    }

    public void setNivelEstudios(NivelEstudios nivelEstudios) {
        this.nivelEstudios = nivelEstudios;
    }

    public String getInstitucion() {
        return institucion;
    }

    public void setInstitucion(String institucion) {
        this.institucion = institucion;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public String getLugarTrabajo() {
        return lugarTrabajo;
    }

    public void setLugarTrabajo(String lugarTrabajo) {
        this.lugarTrabajo = lugarTrabajo;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public List<Pago> getPagos() {
        return pagos;
    }

    public void setPagos(List<Pago> pagos) {
        this.pagos = pagos;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(List<Reserva> reservas) {
        this.reservas = reservas;
    }
    
}
