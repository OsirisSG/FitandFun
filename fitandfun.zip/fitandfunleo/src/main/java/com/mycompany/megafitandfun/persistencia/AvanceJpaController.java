package com.mycompany.megafitandfun.persistencia;

import com.mycompany.megafitandfun.logica.Avance;
import com.mycompany.megafitandfun.logica.Profesor;
import com.mycompany.megafitandfun.persistencia.exceptions.NonexistentEntityException;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public class AvanceJpaController implements Serializable {

    private EntityManagerFactory emf = null;

    public AvanceJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public AvanceJpaController() {
        emf = Persistence.createEntityManagerFactory("fitandJPAPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    // Método para crear un avance
    public void create(Avance avance) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(avance); // Persiste el objeto Avance
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // Método para guardar un avance
    public void guardarAvance(Profesor profesor, int idAlumno, Date fecha, String comentario, String linkVideo, File archivoPDF) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            // Crear el objeto Avance con los datos proporcionados
            Avance avance = new Avance(profesor, idAlumno, fecha, comentario, linkVideo, archivoPDF);

            em.persist(avance);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw e;
        } finally {
            em.close();
        }
    }

    // Método para editar un avance
    public void edit(Avance avance) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            avance = em.merge(avance); // Actualiza el avance en la base de datos
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findAvance(avance.getIdAvance()) == null) {
                throw new NonexistentEntityException("El avance con ID " + avance.getIdAvance() + " no existe.");
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // Método para encontrar un avance por el profesor y el alumno
    public Avance findAvanceByProfesorAndAlumno(Profesor profesor, int idAlumno) {
        EntityManager em = getEntityManager();
        try {
            Query query = em.createQuery(
                "SELECT a FROM Avance a WHERE a.profesor = :profesor AND a.idAlumno = :idAlumno",
                Avance.class
            );
            query.setParameter("profesor", profesor);
            query.setParameter("idAlumno", idAlumno);
            return (Avance) query.getSingleResult();
        } catch (Exception e) {
            return null; // Retorna null si no se encuentra
        } finally {
            em.close();
        }
    }

    // Método para obtener todos los avances
    public List<Avance> findAvanceEntities() {
        return findAvanceEntities(true, -1, -1);
    }

    // Método para obtener un subconjunto de avances
    public List<Avance> findAvanceEntities(int maxResults, int firstResult) {
        return findAvanceEntities(false, maxResults, firstResult);
    }

    private List<Avance> findAvanceEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Avance.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    // Método para encontrar un avance por su ID
    public Avance findAvance(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Avance.class, id);
        } finally {
            em.close();
        }
    }

    // Método para obtener el conteo de avances
    public int getAvanceCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Avance> rt = cq.from(Avance.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
}
