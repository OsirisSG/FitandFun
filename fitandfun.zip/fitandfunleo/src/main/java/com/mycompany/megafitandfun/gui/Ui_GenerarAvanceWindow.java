package com.mycompany.megafitandfun.gui;

import com.mycompany.megafitandfun.logica.Alumno;
import com.mycompany.megafitandfun.logica.Avance;
import com.mycompany.megafitandfun.logica.Clase;
import com.mycompany.megafitandfun.logica.Profesor;
import com.mycompany.megafitandfun.persistencia.AlumnoJpaController;
import com.mycompany.megafitandfun.persistencia.AvanceJpaController;
import com.mycompany.megafitandfun.persistencia.ClaseJpaController;
import com.mycompany.megafitandfun.persistencia.ProfesorJpaController;
import com.mysql.cj.Session;

/*import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;*/
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Ui_GenerarAvanceWindow extends javax.swing.JFrame {

    AlumnoJpaController controlAlumno = new AlumnoJpaController();
    ClaseJpaController controlClase = new ClaseJpaController();
    AvanceJpaController controlAvance = new AvanceJpaController();
    ProfesorJpaController controlProfe = new ProfesorJpaController();
    File pdff;
    String pdfff;
    String emailAlumno;
    
    public Ui_GenerarAvanceWindow() {
        initComponents();
    }

 // Método para enviar correo
    /*private void enviarCorreo(String emailAlumno, String asunto, String mensaje) throws MessagingException {
        // Configuración del servidor SMTP (para Gmail, por ejemplo)
        String host = "smtp.gmail.com";
        final String user = "tucorreo@gmail.com"; // Cambia a tu correo
        final String password = "tucontraseña"; // Cambia a tu contraseña (o usa App Password si usas Gmail con 2FA)

        // Propiedades para la conexión SMTP
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "587");

        // Obtener la sesión de correo
        Session session = Session.getInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, password);
            }
        });

        // Crear el mensaje
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(user));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailAlumno));
        message.setSubject(asunto);
        message.setText(mensaje);

        // Enviar el mensaje
        Transport.send(message);
    }*/
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtAvance = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtPDF = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtBusAlumno = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtLink = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btnSubirPDF = new javax.swing.JButton();
        btnBuscarClase = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnBuscarAlumno = new javax.swing.JButton();
        txtIDClase = new javax.swing.JTextField();
        txtIDAlumno = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtBusClase = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtIDProfe = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("ID clase:");

        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        txtBusAlumno.setColumns(20);
        txtBusAlumno.setRows(5);
        jScrollPane2.setViewportView(txtBusAlumno);

        jLabel4.setText("Avance o Recomendacion:");

        jLabel5.setText("Link:");

        jLabel6.setText("PDF:");

        btnSubirPDF.setText("Subir PDF");
        btnSubirPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubirPDFActionPerformed(evt);
            }
        });

        btnBuscarClase.setText("Buscar");
        btnBuscarClase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarClaseActionPerformed(evt);
            }
        });

        jLabel3.setText("ID Alumno:");

        btnBuscarAlumno.setText("Buscar");
        btnBuscarAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarAlumnoActionPerformed(evt);
            }
        });

        txtBusClase.setColumns(20);
        txtBusClase.setRows(5);
        jScrollPane1.setViewportView(txtBusClase);

        jPanel1.setBackground(new java.awt.Color(33, 69, 113));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Generar Avances");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(44, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(40, 40, 40))
        );

        jLabel7.setText("Ingrese su ID:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSubirPDF)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtPDF, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtLink, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(txtAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 531, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(txtIDClase, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBuscarClase))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtIDAlumno, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBuscarAlumno)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtIDProfe, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(btnBuscarClase)
                        .addComponent(txtIDClase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBuscarAlumno)
                            .addComponent(txtIDAlumno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtLink, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(btnSubirPDF)
                    .addComponent(txtPDF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(txtIDProfe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
// Obtener datos del formulario
String avance = txtAvance.getText().trim();
String link = txtLink.getText().trim();
String idAlumno = txtIDAlumno.getText().trim();
String idClase = txtIDClase.getText().trim();
String idProfe = txtIDProfe.getText().trim();
Date fechaRegistro = new Date();
String emailAlumno;
//File pdff = pdff;  // Asegúrate de que esta variable esté declarada correctamente

// Validaciones de campos vacíos
if (avance.isEmpty() || idAlumno.isEmpty() || idClase.isEmpty() || idProfe.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
    return; // Detiene la ejecución si hay campos vacíos
}

int idClasee;
int idProf;
Profesor profesor;

// Validar y convertir el ID de clase y de profesor
try {
    idClasee = Integer.parseInt(idClase); // Aquí se usa idClasee, el ID de clase
    idProf = Integer.parseInt(idProfe); // Aquí se usa idProfe, el ID del profesor
    profesor = controlProfe.encontrarProfesorPorId(idProf);
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "El ID de la clase y del profesor deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
    return;
} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "No se encontró un profesor con el ID ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}

// Obtener el correo del alumno
int idAlumnoInt;
try {
    idAlumnoInt = Integer.parseInt(idAlumno); // Convertir el ID del alumno a entero
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "El ID del alumno debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}

AlumnoJpaController controlAlumno = new AlumnoJpaController();
emailAlumno = controlAlumno.findEmailById(idAlumnoInt);

if (emailAlumno == null || emailAlumno.isEmpty()) {
    JOptionPane.showMessageDialog(this, "No se encontró un alumno con el ID ingresado o no tiene correo registrado.", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}

// Enviar el correo al alumno (descomentado si quieres implementar el envío de correo)
/*try {
    // Si decides usar esta parte, implementa la función enviarCorreo
    enviarCorreo(emailAlumno, "Registro de Avance", "Se ha registrado un avance: " + avance);
    JOptionPane.showMessageDialog(this, "El correo se envió correctamente a: " + emailAlumno, "Éxito", JOptionPane.INFORMATION_MESSAGE);
} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Error al enviar el correo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}*/

// Asegúrate de que pdff esté asignado correctamente
if (pdff == null) {
    JOptionPane.showMessageDialog(this, "No se ha seleccionado el archivo PDF.", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}

// Crear el objeto Avance y guardarlo
Avance avanceObj = null;
        try {
            avanceObj = new Avance(profesor, idAlumnoInt, fechaRegistro, avance, link, pdff);
        } catch (IOException ex) {
            Logger.getLogger(Ui_GenerarAvanceWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
controlAvance.create(avanceObj);

// Mostrar mensaje de éxito
JOptionPane optionPane = new JOptionPane("Se guardó correctamente");
optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
JDialog dialog = optionPane.createDialog("El avance se ha registrado.");
dialog.setAlwaysOnTop(true);
dialog.setVisible(true);

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnBuscarAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarAlumnoActionPerformed
            // Limpiar el JTextArea
    txtBusAlumno.setText("");
    
    // Solicitar el nombre del alumno a buscar
    String nombreBuscar = JOptionPane.showInputDialog("Dame el nombre del alumno a buscar");

    // Validar que se haya ingresado un nombre
    if (nombreBuscar == null || nombreBuscar.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingresa un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Llamar al controlador para obtener la lista de alumnos
    List<Alumno> alumnosEncontrados = controlAlumno.findAlumnosByNombre(nombreBuscar);

    // Verificar si se encontraron alumnos
    if (!alumnosEncontrados.isEmpty()) {
        txtBusAlumno.append("Alumnos encontrados con el nombre: " + nombreBuscar + "\n\n");
        for (Alumno alumno : alumnosEncontrados) {
            txtBusAlumno.append("Nombre: " + alumno.getNombre() + " " + alumno.getApPat() +" " + alumno.getApMat() + "\n");
            txtBusAlumno.append("ID: " + alumno.getIdAlumno() + "\n");
            txtBusAlumno.append("Correo Electrónico: " + alumno.getEmail() + "\n");
            txtBusAlumno.append("-------------------------------------------\n");
        }
    } else {
        txtBusAlumno.append("No se encontraron alumnos con el nombre: " + nombreBuscar + "\n");
    }
    }//GEN-LAST:event_btnBuscarAlumnoActionPerformed

    private void btnBuscarClaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarClaseActionPerformed
        txtBusClase.setText("");
    
    // Solicitar el nombre del alumno a buscar
    String nombreBuscar = JOptionPane.showInputDialog("Dame la Disciplina de la clase a buscar");

    // Validar que se haya ingresado un nombre
    if (nombreBuscar == null || nombreBuscar.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingresa un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Llamar al controlador para obtener la lista de alumnos
    List<Clase> clasesEncontradas = controlClase.findClasesByDisciplina(nombreBuscar);

    // Verificar si se encontraron alumnos
    if (!clasesEncontradas.isEmpty()) {
        txtBusClase.append("Alumnos encontrados con el nombre: " + nombreBuscar + "\n\n");
        for (Clase clase : clasesEncontradas) {
            txtBusClase.append("Nombre: " + clase.getDisciplina() + "\n");
            txtBusClase.append("ID: " + clase.getIdClase() + "\n");
            txtBusClase.append("-------------------------------------------\n");
        }
    } else {
        txtBusClase.append("No se encontraron alumnos con el nombre: " + nombreBuscar + "\n");
    }
    }//GEN-LAST:event_btnBuscarClaseActionPerformed

    private void btnSubirPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubirPDFActionPerformed
        JFileChooser pdf = new JFileChooser();
        pdf.setFileSelectionMode(JFileChooser.FILES_ONLY);
        
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos pdf", "pdf");
        pdf.setFileFilter(filtro);
        
       int res = pdf.showOpenDialog(this);
        if (res != JFileChooser.CANCEL_OPTION) {
            pdff =pdf.getSelectedFile();
            
            if ((pdff == null)|| pdff.getName().equals("")) {
                JOptionPane.showMessageDialog(this, "Error al abrir el archivo.");
            }else{
                txtPDF.setText(pdff.getAbsolutePath());
            }
        }
    }//GEN-LAST:event_btnSubirPDFActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarAlumno;
    private javax.swing.JButton btnBuscarClase;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnSubirPDF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtAvance;
    private javax.swing.JTextArea txtBusAlumno;
    private javax.swing.JTextArea txtBusClase;
    private javax.swing.JTextField txtIDAlumno;
    private javax.swing.JTextField txtIDClase;
    private javax.swing.JTextField txtIDProfe;
    private javax.swing.JTextField txtLink;
    private javax.swing.JTextField txtPDF;
    // End of variables declaration//GEN-END:variables

    
}
