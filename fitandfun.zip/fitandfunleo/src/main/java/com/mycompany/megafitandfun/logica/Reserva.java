package com.mycompany.megafitandfun.logica;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
public class Reserva implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idReserva;

    @ManyToOne
    @JoinColumn(name = "idAlumno", nullable = false)
    private Alumno alumno;

    @ManyToOne
    @JoinColumn(name = "idClase", nullable = false)
    private Clase clase; // Este será el único mapeo para idClase

    @Temporal(TemporalType.DATE)
    private Date fechaReserva;

    private String avance;
    private String link;

    private File pdf;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    @Transient // Este campo no será mapeado en la base de datos
    private int idClaseTransient; // Campo auxiliar para manejar el ID de clase directamente si es necesario

    @Transient
    private int profeTransient; // Campo auxiliar para manejar el ID del profesor directamente si es necesario

    public enum Estado {
        PENDIENTE, CONFIRMADA
    }

    // Constructores
    public Reserva() {}

    public Reserva(Alumno alumno, Clase clase, Date fechaReserva, String avance, String link, File pdf) {
        this.alumno = alumno;
        this.clase = clase;
        this.fechaReserva = fechaReserva;
        this.avance = avance;
        this.link = link;
        this.pdf = pdf;
    }

    public Reserva(Integer idProfe, Integer idClase, Date fechaReserva, String avance, String link, File pdf) {
        this.profeTransient = idProfe;
        this.idClaseTransient = idClase;
        this.fechaReserva = fechaReserva;
        this.avance = avance;
        this.link = link;
        this.pdf = pdf;
    }

    // Getters y Setters
    public Integer getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(Integer idReserva) {
        this.idReserva = idReserva;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Clase getClase() {
        return clase;
    }

    public void setClase(Clase clase) {
        this.clase = clase;
    }

    public Date getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(Date fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    public String getAvance() {
        return avance;
    }

    public void setAvance(String avance) {
        this.avance = avance;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public File getPdf() {
        return pdf;
    }

    public void setPdf(File pdf) {
        this.pdf = pdf;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public int getIdClaseTransient() {
        return idClaseTransient;
    }

    public void setIdClaseTransient(int idClaseTransient) {
        this.idClaseTransient = idClaseTransient;
    }

    public int getProfeTransient() {
        return profeTransient;
    }

    public void setProfeTransient(int profeTransient) {
        this.profeTransient = profeTransient;
    }
}
