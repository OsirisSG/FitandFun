
package com.mycompany.megafitandfun.logica;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Dias implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idDia;
    @Temporal(TemporalType.DATE)
    private Date fecha;
    private String descripcion;

    @ManyToOne
    @JoinColumn(name = "idClase")
    private Clase clase;

    // Getters y Setters

    public Dias() {
    }

    public Dias(Integer idDia, Date fecha, String descripcion, Clase clase) {
        this.idDia = idDia;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.clase = clase;
    }

    public Integer getIdDia() {
        return idDia;
    }

    public void setIdDia(Integer idDia) {
        this.idDia = idDia;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Clase getClase() {
        return clase;
    }

    public void setClase(Clase clase) {
        this.clase = clase;
    }
    
}