/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.megafitandfun.gui;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.ChartUtilities;
import javax.swing.BorderFactory;
import javax.swing.JFrame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.util.Date;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.BoxLayout;
import org.jfree.data.general.DefaultPieDataset;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;


/**
 *
 * @author leonf
 */
public class Estadisticas extends javax.swing.JFrame {

    /**
     * Creates new form Estadisticas
     */
    public Estadisticas() {
        initComponents();
        
        
        showCharts();
    }

   
    private void showCharts(){
        int edades;
        int edades_count_10_19=0;
        int edades_count_20_29=0;
        int edades_count_30_39=0;
        int edades_count_40=0;
        Date fecha_ingreso;
        int fecha_contador=0;
        Date fecha_hoy = new Date();
        String padecimientos;
        int pad_ninguno_count =0;
        int pad_alergia_count =0;
        int pad_miopia_count =0;
        int pad_tdah_count =0;
        int pad_otros_count =0;
        
        String horario;
        String metodo_pago;
        String estudios;
        int estudios_contador;
        
        Connection SQLConexion;
        
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/bdfitandfun"; // Cambia por tu base de datos
        String usuarioBD = "root"; // Usuario de la base de datos
        String passwordBD = ""; // Contraseña de la base de datos
        jPanel1.setLayout(new BoxLayout(jPanel1,BoxLayout.Y_AXIS));
        
        try{
            
            Class.forName(driver);
            SQLConexion = DriverManager.getConnection(url,usuarioBD, passwordBD);
            String queryAdmin = "SELECT * FROM alumno";
            try (PreparedStatement stmt = SQLConexion.prepareStatement(queryAdmin)) {
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    edades=rs.getInt("EDAD");
                    padecimientos =rs.getString("PADECIMIENTO");
                    fecha_ingreso = rs.getDate("FECHAINGRESO");
                    if(edades<20){
                        edades_count_10_19++;
                    }else if(edades<30){
                        edades_count_20_29++;
                    }
                    else if(edades<40){
                        edades_count_30_39++;
                    }
                    else{
                        edades_count_40++;
                    }
                    switch(padecimientos){
                        case "Ninguno" -> pad_ninguno_count++;
                        case "Alergia" -> pad_alergia_count++;
                        case "Miopia" -> pad_miopia_count++;
                        case "TDAH" -> pad_tdah_count++;
                        default -> pad_otros_count++;
                    }
                }
                    
                CategoryDataset dataset = createDataset1(edades_count_10_19,edades_count_20_29,edades_count_30_39,edades_count_40);
                JFreeChart chart1 = createChart1(dataset);
                ChartPanel chartPanel = new ChartPanel(chart1);
                //chartPanel.setPreferredSize(new Dimension(800,300));
                chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
                chartPanel.setBackground(Color.white);
                jPanel1.add(chartPanel);
                
                JPanel buttonPanel = new JPanel();
                JButton savePngButton = new JButton("Guardar como PNG");
                JButton savePdfButton = new JButton("Guardar como PDF");

                buttonPanel.add(savePngButton);
                buttonPanel.add(savePdfButton);
                jPanel1.add(buttonPanel, BorderLayout.SOUTH);

                // Acción para guardar como PNG
                savePngButton.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PNG");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try {
                            ChartUtilities.saveChartAsPNG(new File(fileToSave + ".png"), chart1, 800, 600);
                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PNG.");
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });

                // Acción para guardar como PDF
                savePdfButton.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PDF");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try (FileOutputStream fos = new FileOutputStream(fileToSave + ".pdf")) {
                            Document document = new Document();
                            PdfWriter writer = PdfWriter.getInstance(document, fos);
                            document.open();

                            // Exportar la gráfica al PDF
                            com.itextpdf.text.Image chartImage = com.itextpdf.text.Image.getInstance(
                                    ChartUtilities.encodeAsPNG(chart1.createBufferedImage(400, 300)));
                            document.add(chartImage);
                            document.close();

                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PDF.");
                        } catch (IOException | DocumentException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });

                
                
                pack();
                setTitle("Estadísticas");
                setLocationRelativeTo(null);

                DefaultPieDataset dataset2 = createDataset2(pad_ninguno_count, pad_miopia_count, pad_alergia_count,pad_tdah_count,pad_otros_count);

                JFreeChart chart2 = createChart2(dataset2);
                ChartPanel chartPanel2 = new ChartPanel(chart2);
                chartPanel2.setMouseWheelEnabled(true);
                //chartPanel2.setPreferredSize(new Dimension(800,300));
                chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
                chartPanel.setBackground(Color.white);
                jPanel1.add(chartPanel2);
                
                JPanel buttonPanel2 = new JPanel();
                JButton savePngButton2 = new JButton("Guardar como PNG");
                JButton savePdfButton2 = new JButton("Guardar como PDF");

                buttonPanel2.add(savePngButton2);
                buttonPanel2.add(savePdfButton2);
                jPanel1.add(buttonPanel2, BorderLayout.SOUTH);

                // Acción para guardar como PNG
                savePngButton2.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PNG");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try {
                            ChartUtilities.saveChartAsPNG(new File(fileToSave + ".png"), chart2, 800, 600);
                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PNG.");
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });

                // Acción para guardar como PDF
                savePdfButton2.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PDF");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try (FileOutputStream fos = new FileOutputStream(fileToSave + ".pdf")) {
                            Document document = new Document();
                            PdfWriter writer = PdfWriter.getInstance(document, fos);
                            document.open();

                            // Exportar la gráfica al PDF
                            com.itextpdf.text.Image chartImage = com.itextpdf.text.Image.getInstance(
                                    ChartUtilities.encodeAsPNG(chart2.createBufferedImage(400, 300)));
                            document.add(chartImage);
                            document.close();

                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PDF.");
                        } catch (IOException | DocumentException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });
                    
                
            }
            queryAdmin = "SELECT FECHAINGRESO, COUNT(*) AS repeticiones  FROM alumno GROUP BY FECHAINGRESO";
            try (PreparedStatement stmt = SQLConexion.prepareStatement(queryAdmin)) {
                ResultSet rs = stmt.executeQuery();
                DefaultCategoryDataset dataset3 = new DefaultCategoryDataset();
    	
                while (rs.next()) {
                    fecha_ingreso=rs.getDate("FECHAINGRESO");
                    fecha_contador =rs.getInt("repeticiones");

                    //CategoryDataset dataset3 = createDataset3(fecha_contador, fecha_ingreso);
                    dataset3.addValue(fecha_contador, "", fecha_ingreso);
                    
                }
                JFreeChart chart3 = createChart3(dataset3);
                ChartPanel chartPanel3 = new ChartPanel(chart3);
                //chartPanel3.setPreferredSize(new Dimension(800,300));
                chartPanel3.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
                chartPanel3.setBackground(Color.white);
                jPanel1.add(chartPanel3);
                
                JPanel buttonPanel3 = new JPanel();
                JButton savePngButton3 = new JButton("Guardar como PNG");
                JButton savePdfButton3 = new JButton("Guardar como PDF");

                buttonPanel3.add(savePngButton3);
                buttonPanel3.add(savePdfButton3);
                jPanel1.add(buttonPanel3, BorderLayout.SOUTH);

                // Acción para guardar como PNG
                savePngButton3.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PNG");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try {
                            ChartUtilities.saveChartAsPNG(new File(fileToSave + ".png"), chart3, 800, 600);
                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PNG.");
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });

                // Acción para guardar como PDF
                savePdfButton3.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PDF");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try (FileOutputStream fos = new FileOutputStream(fileToSave + ".pdf")) {
                            Document document = new Document();
                            PdfWriter writer = PdfWriter.getInstance(document, fos);
                            document.open();

                            // Exportar la gráfica al PDF
                            com.itextpdf.text.Image chartImage = com.itextpdf.text.Image.getInstance(
                                    ChartUtilities.encodeAsPNG(chart3.createBufferedImage(400, 300)));
                            document.add(chartImage);
                            document.close();

                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PDF.");
                        } catch (IOException | DocumentException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });
            }
            queryAdmin = "SELECT NIVELESTUDIOS, COUNT(*) AS cuantos  FROM alumno GROUP BY NIVELESTUDIOS";
            try (PreparedStatement stmt = SQLConexion.prepareStatement(queryAdmin)) {
                ResultSet rs = stmt.executeQuery();
                DefaultPieDataset dataset4 = new DefaultPieDataset();
    	
                while (rs.next()) {
                    estudios=rs.getString("NIVELESTUDIOS");
                    estudios_contador =rs.getInt("cuantos");

                    //CategoryDataset dataset3 = createDataset3(fecha_contador, fecha_ingreso);
                    dataset4.setValue(estudios, estudios_contador);
                    
                }
                JFreeChart chart4 = createChart4(dataset4);
                ChartPanel chartPanel4 = new ChartPanel(chart4);
                //chartPanel4.setPreferredSize(new Dimension(800,300));
                chartPanel4.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
                chartPanel4.setBackground(Color.white);
                
                jPanel1.add(chartPanel4);
                
                JPanel buttonPanel4 = new JPanel();
                JButton savePngButton4 = new JButton("Guardar como PNG");
                JButton savePdfButton4 = new JButton("Guardar como PDF");

                buttonPanel4.add(savePngButton4);
                buttonPanel4.add(savePdfButton4);
                jPanel1.add(buttonPanel4, BorderLayout.SOUTH);

                // Acción para guardar como PNG
                savePngButton4.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PNG");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try {
                            ChartUtilities.saveChartAsPNG(new File(fileToSave + ".png"), chart4, 800, 600);
                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PNG.");
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });

                // Acción para guardar como PDF
                savePdfButton4.addActionListener(e -> {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Guardar como PDF");
                    int userSelection = fileChooser.showSaveDialog(jPanel1);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try (FileOutputStream fos = new FileOutputStream(fileToSave + ".pdf")) {
                            Document document = new Document();
                            PdfWriter writer = PdfWriter.getInstance(document, fos);
                            document.open();

                            // Exportar la gráfica al PDF
                            com.itextpdf.text.Image chartImage = com.itextpdf.text.Image.getInstance(
                                    ChartUtilities.encodeAsPNG(chart4.createBufferedImage(400, 300)));
                            document.add(chartImage);
                            document.close();

                            JOptionPane.showMessageDialog(jPanel1, "Gráfica guardada como PDF.");
                        } catch (IOException | DocumentException ex) {
                            JOptionPane.showMessageDialog(jPanel1, "Error al guardar la gráfica: " + ex.getMessage());
                        }
                    }
                });
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        }
    } 

    private JFreeChart createChart4(DefaultPieDataset dataset) {

        JFreeChart pieChart = ChartFactory.createPieChart(
                "Alumnos por nivel de estudios",
                dataset,
                false, true, false);

        return pieChart;
    }
    private JFreeChart createChart3(CategoryDataset dataset) {

        JFreeChart barChart = ChartFactory.createBarChart(
                "Alumnos por fecha de ingreso",
                "",
                "Ingresos",
                dataset,
                PlotOrientation.VERTICAL,
                false, true, false);

        return barChart;
    }
    
    private DefaultPieDataset createDataset2(int pad_ninguno_count, int pad_miopia_count, int pad_alergia_count,int pad_tdah_count,int pad_otros_count) {

        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Ninguna", pad_ninguno_count);
        dataset.setValue("Miopia", pad_miopia_count);
        dataset.setValue("Alergia", pad_alergia_count);
        dataset.setValue("TDAH", pad_tdah_count);
        dataset.setValue("Otros", pad_otros_count);

        return dataset;
    }

    private JFreeChart createChart2(DefaultPieDataset dataset) {

        JFreeChart pieChart = ChartFactory.createPieChart(
                "Alumnos por padecimiento",
                dataset,
                true, true, false);

        return pieChart;
    }
 
    private CategoryDataset createDataset1(int edades_count_10_19,int edades_count_20_29,int edades_count_30_39,int edades_count_40) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    	dataset.addValue(edades_count_10_19,"Edad", "10-19");
        dataset.addValue(edades_count_20_29,"Edad","20-29");
        dataset.addValue(edades_count_30_39,"Edad", "30-39");
        dataset.addValue(edades_count_40,"Edad", "40+");

        return dataset;
    }

    private JFreeChart createChart1(CategoryDataset dataset) {

        JFreeChart barChart = ChartFactory.createBarChart(
                "Alumnos por edades",
                "",
                "Edad",
                dataset,
                PlotOrientation.VERTICAL,
                false, true, false);

        return barChart;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Estadísticas");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 30, -1, -1));

        jScrollPane1.setPreferredSize(new java.awt.Dimension(450, 100));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setMinimumSize(new java.awt.Dimension(100, 100));
        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 890, 420));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
