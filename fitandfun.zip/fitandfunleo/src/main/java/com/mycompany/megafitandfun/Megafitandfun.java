package com.mycompany.megafitandfun;

//import com.mycompany.megafitandfun.persistencia.ControladoraPersistencia;

import com.mycompany.megafitandfun.gui.Principal;



public class Megafitandfun {
  
    public static void main(String [] args){
        //ControladoraPersistencia controlPersis = new ControladoraPersistencia();
        Principal login = new Principal();
        login.setVisible(true);
        login.setLocationRelativeTo(null);
        //setIconImage(new ImageIcon(getClass().getResource("/resources/tu_icono.png")).getImage());
    }
}
